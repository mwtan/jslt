# Java Cache SDK

A shared library that provides distributed caching capabilities to Java applications. It is 
included into applications as a Maven dependency and abstracts the access to the underlying 
AWS ElastiCache for Redis services and interactions with the Redis client. It retrieves 
credentials stored in Vault and caching configuration settings from environment variables
(i.e. manifest). The SDK simplifies the use of caching and exposes a number of methods for 
storing and fetching objects including Live Java collections classes. These Live Objects 
synchronize changes to the object to other object instances in distributed JVMs.

![Cache SDK Diagram](component.png)

## Maven Dependency
For projects using JDK 11, include the following into your pom.xml:
```
    <dependency>
        <groupId>com.aig.lnr.cache</groupId>
        <artifactId>cachesdk</artifactId>
        <version>1.0</version>
    </dependency>
```
For JDK 8, use:
```
    <dependency>
        <groupId>com.aig.lnr.cache</groupId>
        <artifactId>cachesdk-jdk8</artifactId>
        <version>1.0</version>
    </dependency>
```

## Configuration
The following system properties are needed in the application manifest:
```
    cache.url           - The ElastiCache/Redis url. (Required)
    cache.appname       - The application name used as a namespace to partition cached pobjects. (Required)
                          (See 'Cache Keys and Application Name' below.)
    cache.default.ttlms - Default time-to-live for cached data in milliseconds. (Optional. Default is 24 hours.)
    cache.secretname    - Secretname for retrieval of credentials from SecretsManager. This is the Vault mount path. (Required)
	cache.password      - The cache password. (Optional. Only used for development when cache.secretname is omitted.)
    vault.base.url      - Vault url. (Required)
    vault.api.key       - Vault apikey. (Required)
    vault.role.id       - Vault roleid. (Required)
```
(The `vault.secret.id` system property is injected at runtime.)

Within the Vault secretname (Mount path), the following attributes are needed:
```
    cache.password - The password to the ElastiCache/Redis cluster.
```

## Examples
Credentials needed by CacheClient are retrieved from Vault and is cached such that subsequent 
instances of CacheClient do not access Vault. The examples below show the use of the CacheClient 
which utilizes the Singleton pattern and the various cache operations. Calling ```CacheClient.getInstance()```
during application initialization avoids deferring the CacheClient startup to the first use of cache.

### Storing and fetching objects
Objects are stored and retrieved from cache using a key reference. Objects cached in this
manner are not 'Live objects' (see below) and changes must be persisted and retrieved from
cache explicitly. Objects cached must implement the Serializable interface.
```
    CacheClient cacheclient = CacheClient.getInstance();
    String strorig = "This is a test";
    cacheclient.storeObject("myid", strorig);
    String strcached = (String) cacheclient.fetchObject("myid", String.class);
```
The time-to-live (in milliseconds) can be specified in the storeObject method. This overrides 
the default time-to-live value set using the cache.default.ttlms configuration property.
```
    cacheclient.storeObject("myid", strorig, 3600000);
```

### Local Cached Map:
This is a locally cached Map object which performs significantly faster because it does
not access the cache synchronously. The Map is backed by the cache where updates are written
to cache asynchronously. The Map object is also a Live Object such that changes are reflected 
across all instances. A Local Cached Map is referenced using a key and is created as follows:
```
    CacheClient cacheclient = CacheClient.getInstance();
    Map map = cacheclient.fetchLocalCachedMap("mylocalmap");
    map.put("key1", "value1");

    Map map2 = cacheclient.fetchLocalCachedMap("mylocalmap");
    map2.containsKey("key1")

    // Changes to map is reflected in map2
    map.put("key2", "value2");
    map2.containsKey("key2");

    // And vice versa
    map2.put("key3", "value3");
    map.containsKey("key3");
```

### Live Java Collections
Live objects for Java collection types List, Map, Queue, Set and SortedSet are available. e.g.
```
    CacheClient cacheclient = CacheClient.getInstance();
    List list = cacheclient.fetchLiveList("mylist");
    ist.add("String value one");

    List list2 = cacheclient.fetchLiveList("mylist");
    list2.contains("String value one");

    // Additions to the original list updates the remote list
    list.add("String value two");
    list2.contains("String value two");

    // Additions to the 'remote' list updates the original list
    list2.add("String value three");
    list.contains("String value three");                                                   
```
These collection objects are Live, such that modifications to the object are propagated to 
object instances with the same key name in other JVMs.

### Retrieving Keys
Object keys present in cache can be retrieved. The following retrieves all available keys and
iterates through them:
```
    CacheClient cacheclient = CacheClient.getInstance();
    for (String s : cacheclient.getAllKeys()) {
        ...
    }
```
Keys can also be retrieved using a glob pattern:
```
    CacheClient cacheclient = CacheClient.getInstance();
    for (String s : cacheclient.getKeysByPattern("mykey*")) {
        ...
    }
```

### Deleting Objects
Objects in cache can be deleted (or invalidated) using the specific key or a key pattern.
```
    CacheClient cacheclient = CacheClient.getInstance();
    cacheclient.delete("mykey1:java.lang.Class");
```
Delete multiple objects by key name:
```
    CacheClient cacheclient = CacheClient.getInstance();
    cacheclient.delete(new String[] {"mykey1:java.lang.Class", "mykey2:java.lang.Class"});
```
Delete multiple objects using a glob pattern:
```
    CacheClient cacheclient = CacheClient.getInstance();
    cacheclient.deleteByPattern("mykey1*");
```

## Cache Keys and Application Name
If supplied via the `cache.appname` property, all cache operations using object keys are 
automatically prepended with the application name. Objects in the cache will have keys in
the format:
```
    {appname}:{keyname}
```
Applications using the CacheSDK should only be concerned with the keyname used to reference
objects. The application name is used internally as a namespace to partition application data.

## CacheClient Optimization and Performance
Although CacheClient caches credentials retrieved from Vault and avoids subsequent calls to Vault, 
instantiating a CacheClient incurs some overhead. This can take several hundred milliseconds and 
depends on the number of nodes configured in the cluster. As mentioned earlier, CacheClient.getInstance() 
can be called during application initialization to pre-connect the Redis cluster and avoid deferring 
startup overhead until the first use of cache.

In the application shutdown process, the cacheclient should be shut down, e.g. in a SpringBoot application,
```
    @PreDestroy
    public void onExit() {
        LOGGER.info("DataCachingApplication stopping...");
        CacheClient.removeInstance();
    }
```


Fetch and Store operations generally take between 1-2 milliseconds.

## Javadocs
See the CacheClient Javadoc at: https://github.aig.net/pages/mtan/cachesdk-javadoc/apidocs/com/aig/lnr/cache/CacheClient.html