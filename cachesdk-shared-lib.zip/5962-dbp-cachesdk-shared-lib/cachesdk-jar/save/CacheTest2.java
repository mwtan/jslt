package com.aig.lnr.cache;

import java.util.List;

import com.aig.lnr.secret.SecretsManager;
import com.aig.lnr.secret.VaultSecretProvider;

public class CacheTest2 {

    public static void main(String[] args) {
        System.setProperty(VaultSecretProvider.CONST_VAULT_URL_PROP, "https://uat.cloud.api.aig.net/life/connext-secrets-api/v1/secrets/lnr/life/environment-on-demand");
        System.setProperty(VaultSecretProvider.CONST_VAULT_APIKEY_PROP, "AQ1Lh57p7mbVsQX8XmuwcFGk9GIGu10e");
        System.setProperty(VaultSecretProvider.CONST_VAULT_ROLEID_PROP, "8eba7ae6-2e19-5c09-be17-632490f4adb4");
        System.setProperty(VaultSecretProvider.CONST_VAULT_SECRETID_PROP, "9561a47f-5f5c-6244-4336-61e8fa9fa37d");
        System.setProperty(CacheClient.CONST_CACHE_URL_PROP, "rediss://redis-17112.c9.us-east-1-4.ec2.cloud.redislabs.com:17112");
        System.setProperty(CacheClient.CONST_CACHE_SECRETNAME_PROP, "credentials");
        System.setProperty(SecretsManager.CONST_SECRET_PROVIDER_PROP, "");

        CacheClient cacheclient = CacheClient.getReference();
        List<String> list = (List) cacheclient.fetchLiveList("mylist");
        while (true) {
            if (list == null) {
                System.out.println("Null list.");
            }
            else {
                System.out.println(list.toString());
            }
            try {
                Thread.sleep(1500);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
