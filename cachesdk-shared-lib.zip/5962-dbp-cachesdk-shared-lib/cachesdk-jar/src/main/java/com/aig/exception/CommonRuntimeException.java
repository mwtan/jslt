package com.aig.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aig.lnr.util.Sanitizer;

/**
 * General exception class that enables exception chaining.
 *
 * @author Will Tan
 * <br>04/20/20 Will Tan    - Renamed log to LOGGER.
 * <br>03/03/21 Will Tan    - Sonar changes.
 */
public class CommonRuntimeException extends RuntimeException {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonRuntimeException.class);
    private static final long serialVersionUID = -7329856070780733749L;
    private final Exception chainedException;

    /**
     * Default constructor.
     */
    public CommonRuntimeException() {
        super();
        chainedException = null;
    }

    /**
     * Constructs a CommonException with a supplied message and nested exception.
     * <p>
     * @param inMessage - a descriptive message
     * @param inException - the underlying trapped exception
     */
    public CommonRuntimeException(String inMessage, Exception inException) {
        super(inMessage, inException);
        chainedException = inException;
    }

    /**
     * Constructs a CommonException with a supplied message.
     * <p>
     * @param inMessage - a descriptive message
     */
    public CommonRuntimeException(String inMessage) {
        super(inMessage);
        chainedException = null;
        logException();
    }

    /**
     * Constructs a CommonException with a nested exception.
     * <p>
     * @param inException - the underlying trapped exception
     */
    public CommonRuntimeException(Exception inException) {
        super(inException);
        chainedException = inException;
    }

    private void logException() {
        if (LOGGER.isErrorEnabled()) {
            LOGGER.error(Sanitizer.sanitize(getPrintStackTrace()));
        }
    }

    /**
     * Returns the embedded root cause if there is one, otherwise
     * returns itself. This method navigates through all embedded
     * causes until it finds the innermost Exception.
     * <p>
     * @return Exception representing the root embedded cause
     */
    public Exception getRootCause() {
        if (chainedException == null) {
            return this;
        }
        else {
            if (chainedException instanceof CommonRuntimeException) {
                return ((CommonRuntimeException) chainedException).getRootCause();
            }
            else {
                return chainedException;
            }
        }
    }

    /**
     * Returns the next Exception (cause) in the chain of Exceptions.
     * <p>
     * @return Exception representing the next Exception.
     */
    public Exception getNextCause() {
        if (chainedException == null) {
            return null;
        }
        else {
            return chainedException;
        }
    }

    /**
     * Returns the stack trace as a string for this exception.
     * <p>
     * @return String printStackTrace output
     */
    public String getPrintStackTrace() {
        return CommonRuntimeException.getPrintStackTrace(this);
    }

    /**
     * Returns the stack trace as a string for the root exception.
     * <p>
     * @return String printStackTrace output
     */
    public String getRootPrintStackTrace() {
        return CommonRuntimeException.getPrintStackTrace(this.getRootCause());
    }

    /**
     * Returns the stack trace as a string for the provided exception.
     * <p>
     * @param ex The exception object.
     * @return String printStackTrace output
     */
    public static String getPrintStackTrace(Exception ex) {
        StringWriter sWriter = new StringWriter();
        PrintWriter pWriter = new PrintWriter(sWriter);
        ex.printStackTrace(pWriter);
        return sWriter.toString();
    }
}
