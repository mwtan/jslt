package com.aig.exception;

/**
 * Allows retryable error conditions to be handled by com.github.rholder.retry.Retryer
 * for retrying code execution.
 * <p> 
 * @author Will Tan
 */
public class RetryableException extends CommonException {
    private static final long serialVersionUID = -5107681109366420507L;
    
    public RetryableException(Exception e) {
        super(e);
    }

    public RetryableException(String message) {
        super(message);
    }

    public RetryableException(String message, Exception e) {
        super(message, e);
    }
}
