package com.aig.exception;

/**
 * Common exception classes. 
 * <p>
 * @author Will Tan
 */
