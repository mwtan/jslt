package com.aig.lnr.cache;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.LocalCachedMapOptions;
import org.redisson.api.MapOptions;
import org.redisson.api.RBucket;
import org.redisson.api.RKeys;
import org.redisson.api.RedissonClient;
import org.redisson.api.redisnode.RedisCluster;
import org.redisson.api.redisnode.RedisClusterMaster;
import org.redisson.api.redisnode.RedisClusterSlave;
import org.redisson.api.redisnode.RedisNode;
import org.redisson.api.redisnode.RedisNodes;
import org.redisson.config.ClusterServersConfig;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aig.exception.CommonRuntimeException;
import com.aig.lnr.secret.SecretsManager;
import com.aig.lnr.util.ConfigManager;
import com.aig.lnr.util.Sanitizer;

/**
 * Cache services for Java.
 * <p>
 * <u><b>System Properties</b></u>
 * <pre>{@code
 * cache.url                - Redis url. (Required)
 * cache.appname            - Application name used to partition cached objects. (Optional)
 * cache.clustermode        - Use cluster mode (Optional. Default is true.)
 * cache.default.ttlms      - Default time-to-live for cached data in milliseconds. (Optional. Default is 24 hours.)
 * cache.secretname         - Secretname for retrieval of credentials from SecretsManager. (Required if ElastiCache/Redis password secured.)
 * cache.username           - Username for ElastiCache/Redis. (Optional - for testing only. Normally not required.)
 * cache.password           - Password for ElastiCach/Redise. (Optional - for testing only.)
 * }</pre>
 * <p>
 * <u><b>Vault properties</b></u>
 * <pre>{@code
 * vault.base.url           - Vault url. (Optional - only needed when credentials are stored in Vault.)
 * vault.api.key            - Vault apikey. (Optional - only needed when credentials are stored in Vault.)
 * vault.role.id            - Vault roleid. (Optional - only needed when credentials are stored in Vault.)
 * vault.secret.id          - Vault secretid. (Not needed. Inserted by Jenkins.)
 * }</pre>
 * <p>
 * @author Will Tan
 * <br>09/14/20 Will Tan    - Initial version.
 * <br>09/19/20 Will Tan    - Use SecretsManager with cached secrets.
 * <br>09/19/20 Will Tan    - Added testmode to avoid connecting to Redis server.
 * <br>09/30/20 Will Tan    - Removed fetchLiveObject and storeLiveObject. Added get and delete methods.
 * <br>11/24/20 Will Tan    - Added logger. Log cache url.
 * <br>11/30/20 Will Tan    - Changes to use ElastiCache.
 * <br>12/01/20 Will Tan    - Retrieve configs using ConfigManager.
 * <br>12/03/20 Will Tan    - Enable the use of application name to partition cached objects.
 * <br>12/03/20 Will Tan    - Corrected class name in createClassKey.
 * <br>12/04/20 Will Tan    - Sonar changes.
 * <br>01/06/21 Will Tan    - Default cache.clustermode to true.
 * <br>01/08/21 Will Tan    - Enable alternate application name in cache methods.
 * <br>01/12/21 Will Tan    - Removed alternate application name methods.
 * <br>01/13/21 Will Tan    - Sonar changes.
 * <br>01/26/21 Will Tan    - Modified to Singleton pattern.
 * <br>02/09/21 Will Tan    - Added getClusterInfo().
 * <br>02/12/21 Will Tan    - Capture cache stats for CacheClient instance.
 * <br>03/01/21 Will Tan    - Added fetchObjectByKey.
 * <br>03/03/21 Will Tan    - Sonar changes.
 */
public class CacheClient {
    private static final int CONST_STAT_MAP_SIZE = 64;
    private static final Logger LOGGER = LoggerFactory.getLogger(CacheClient.class);
    public static final String CONST_CACHE_URL_PROP         = "cache.url";
    public static final String CONST_CACHE_CLUSTERMODE_PROP = "cache.clustermode";
    public static final String CONST_CACHE_APPNAME_PROP     = "cache.appname";
    public static final String CONST_CACHE_SECRETNAME_PROP  = "cache.secretname";
    public static final String CONST_CACHE_USER_PROP        = "cache.username";
    public static final String CONST_CACHE_PPHRASE_PROP     = "cache.password";
    public static final String CONST_DEFAULT_TTL_PROP       = "cache.default.ttlms";
    private static final long CONST_DEFAULT_TTL             = 86_400_400;
    private static CacheClient singleton;
    private RedissonClient redisson;
    private long timeToLiveMs;
    private String appname;
    private Map<String, CacheObjectStats> statsmap = new HashMap<>(CONST_STAT_MAP_SIZE);
    private static boolean testmode;
    
    /**
     * Constructs the CacheClient object.
     */
    private CacheClient() {
        // Cache URL
        String cacheurl = getCacheURL();
        // Cluster mode
        boolean useclustermode = ConfigManager.getBooleanProperty(CONST_CACHE_CLUSTERMODE_PROP, true);
        LOGGER.info("Use clustered server mode: {}", useclustermode);
        // Application name
        getAppName();
        // Cache password
        String secretname = ConfigManager.getProperty(CONST_CACHE_SECRETNAME_PROP);
        String cacheusername = "";
        String cachepassword = "";
        if (!StringUtils.isBlank(secretname)) {
            SecretsManager secretsmanager = SecretsManager.getReference();
            Map<String, String> secrets = secretsmanager.getSecrets(secretname);
            cacheusername = secrets.get(CONST_CACHE_USER_PROP);
            cachepassword = secrets.get(CONST_CACHE_PPHRASE_PROP);
        }
        else {
            cacheusername = ConfigManager.getProperty(CONST_CACHE_USER_PROP);
            cachepassword = ConfigManager.getProperty(CONST_CACHE_PPHRASE_PROP);
        }
        // Default TTL
        timeToLiveMs = getDefaultTTL();
        // Config redis
        Config config = new Config();
        if (useclustermode) {
            configureClusterServer(config, cacheurl, cacheusername, cachepassword);
        }
        else {
            configureSingleServer(config, cacheurl, cacheusername, cachepassword);
        }
        // Create client
        createClient(config);
    }

    /**
     * Retrieves the singleton CacheClient object.
     * @return The CacheClient object.
     */
    public static CacheClient getInstance() {
        if (singleton == null) {
            singleton = new CacheClient();
        }
        return singleton;
    }
    
    /**
     * Closes and destroys the CacheClient singleton.
     */
    public static void removeInstance() {
        if (singleton != null) {
            singleton.close();
            singleton = null;
        }
        LOGGER.info("CacheClient destroyed.");
    }

    private static String getCacheURL() {
        String cacheurl = ConfigManager.getProperty(CONST_CACHE_URL_PROP);
        if (StringUtils.isBlank(cacheurl)) {
            throw new CommonRuntimeException("Cache URL is missing.");
        }
        else {
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Using cache URL: {}", Sanitizer.sanitize(cacheurl));
            }
        }
        return cacheurl;
    }

    private static void configureClusterServer(Config config, String cacheurl, String cacheusername, String cachepassword) {
        ClusterServersConfig csconfig = config.useClusterServers().addNodeAddress(cacheurl);
        if (!StringUtils.isBlank(cacheusername)) {
            csconfig.setUsername(cacheusername);
        }
        if (!StringUtils.isBlank(cachepassword)) {
            csconfig.setPassword(cachepassword);
        }
    }

    private static void configureSingleServer(Config config, String cacheurl, String cacheusername, String cachepassword) {
        SingleServerConfig ssconfig = config.useSingleServer().setAddress(cacheurl);
        if (!StringUtils.isBlank(cacheusername)) {
            ssconfig.setUsername(cacheusername);
        }
        if (!StringUtils.isBlank(cachepassword)) {
            ssconfig.setPassword(cachepassword);
        }
    }

    private void createClient(Config config) {
        if (!testmode) {
            redisson = Redisson.create(config);
        }
    }

    private void getAppName() {
        appname = ConfigManager.getProperty(CONST_CACHE_APPNAME_PROP);
        if (!StringUtils.isBlank(appname)) {
            appname = appname + ":";
        }
        else {
            appname = "";
        }
    }
    
    private static long getDefaultTTL() {
        String defaultTTLstr = ConfigManager.getProperty(CONST_DEFAULT_TTL_PROP);
        if (!StringUtils.isBlank(defaultTTLstr)) {
            return Long.parseLong(defaultTTLstr);
        }
        else {
            return CONST_DEFAULT_TTL;
        }
    }

    /**
     * Retrieves information and stats for each master and slave node in the Redis cluster.
     * <p>
     * @return A list of Map objects containing details for each node. 
     */
    public List<Map<String, String>> getClusterInfo() {
        List<Map<String, String>> infolist = new ArrayList<>();
        RedisCluster nodes = redisson.getRedisNodes(RedisNodes.CLUSTER);
        for (RedisClusterMaster master : nodes.getMasters()) {
            Map<String, String> infomap = master.info(RedisNode.InfoSection.ALL);
            infolist.add(infomap);
        }
        for (RedisClusterSlave slave : nodes.getSlaves()) {
            Map<String, String> infomap = slave.info(RedisNode.InfoSection.ALL);
            infolist.add(infomap);
        }
        return infolist;
    }
    
    /**
     * Fetches an object from cache given the key and object class. 
     * Note: the object stored and fetched is not a live object, i.e. changes to the object are not 
     * reflected in other distributed instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {
     *         String strorig = "This is a test";
     *         cacheclient
     *             .timeToLiveMillis(10000)
     *             .storeObject("myid", strorig);
     *         String strcached = (String) cacheclient.fetchObject("myid", String.class);
     *     }
     * }</pre>
     * <p>
     * @param key A key or id under which one or more objects are cached.
     * @param c The object class.
     * @return The cached object.
     */
    public Object fetchObject(String key, Class c) {
        return fetchObjectByKey(createClassKey(key, c));
    }
    
    /**
     * Fetches an object from cache using the absolute key.
     * <p>
     * @param key The complete key of the cached object in the cache.
     * @return The cached object.
     */
    public Object fetchObjectByKey(String key) {
        RBucket<Object> bucket = redisson.getBucket(key);
        Object obj = bucket.get();
        CacheObjectStats keystat = getObjectStatMap(key);
        if (obj == null) {
            keystat.incrementMissCount();
        }
        else {
            keystat.incrementHitCount();
        }
        return obj;
    }

    /**
     * Retrieve the CacheObjectStats object for the specified object key.
     * <p>
     * @param key
     * @return
     */
    private CacheObjectStats getObjectStatMap(String key) {
        return statsmap.computeIfAbsent(key, k -> new CacheObjectStats(k, Instant.now()));
    }
    
    /**
     * Stores an object to cache using the key and object class. It allows a given key to contain
     * multiple object types. The time-to-live will use the default specified using the property
     * cache.default.ttlms or 24 hours if cache.default.ttlms is omitted. 
     * <p>
     * Note: the object stored and fetched is not a live object, i.e. changes to the object are not 
     * reflected in other distributed instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {
     *         String strorig = "This is a test";
     *         cacheclient
     *             .timeToLiveMillis(10000)
     *             .storeObject("myid", strorig);
     *         String strcached = (String) cacheclient.fetchObject("myid", String.class);
     *     }
     * }</pre>
     * <p>
     * @param key A key or id that references the cached object.
     * @param obj The object to cache.
     */
    public void storeObject(String key, Object obj) {
        RBucket<Object> bucket = redisson.getBucket(createClassKey(key, obj.getClass()));
        bucket.set(obj, timeToLiveMs, TimeUnit.MILLISECONDS);
        getObjectStatMap(key);
    }
    
    /**
     * Stores an object to cache using the key and object class, allowing the time-to-live to be
     * specified. This value overrides the default time-to-live used for the object stored. 
     * <p>
     * @see storeObject(String key, Object obj)
     * @param key A key or id that references the cached object
     * @param obj The object to cache.
     * @param ttlms The time-to-live of the cached object in milliseconds. This overrides the 
     *              default time-to-live specified in the cache.default.ttlms property.
     */
    public void storeObject(String key, Object obj, long ttlms) {
        RBucket<Object> bucket = redisson.getBucket(createClassKey(key, obj.getClass()));
        if (ttlms == 0) {
            ttlms = timeToLiveMs;
        }
        bucket.set(obj, ttlms, TimeUnit.MILLISECONDS);
    }

    /**
     * Retrieves an object from cache and replaces it with a new object.
     * <p> 
     * @param key A key or id under which one or more objects are cached.
     * @param obj The object to cache.
     * @return The previous cached object.
     */
    public Object replaceObject(String key, Object obj) {
        RBucket<Object> bucket = redisson.getBucket(createClassKey(key, obj.getClass()));
        return bucket.getAndSet(obj, timeToLiveMs, TimeUnit.MILLISECONDS);
    }
    
    public Object replaceObject(String key, Object obj, long ttlms) {
        RBucket<Object> bucket = redisson.getBucket(createClassKey(key, obj.getClass()));
        return bucket.getAndSet(obj, ttlms, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Retrieve or create a locally cached Map object which performs significantly faster. 
     * The Map is backed by the cache where updates are written to cache asynchronously. 
     * The Map object is also live such that changes are reflected across all instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {
     *         Map map = cacheclient.fetchLocalCachedMap("mylocalmap");
     *         map.put("key1", "value1");
     *
     *         Map map2 = cacheclient.fetchLocalCachedMap("mylocalmap");
     *         map2.containsKey("key1")
     *         
     *         map.put("key2", "value2");
     *         map2.containsKey("key2");
     *
     *         map2.put("key3", "value3");
     *         map.containsKey("key3");
     *     }
     * }</pre>
     * <p> 
     * @param key The key to the Map instance.
     * @return A java.util.Map object. If the Map object does not exist, an empty Map is returned.
     */
    public Map fetchLocalCachedMap(String key) {
        LocalCachedMapOptions options = LocalCachedMapOptions.defaults()
                .writeMode(MapOptions.WriteMode.WRITE_BEHIND);
        return redisson.getLocalCachedMap(prependAppName(key), options);
    }

    /**
     * Retrieve or create a cached live List object. Changes to the list are propagated to 
     * all object instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {   
     *         List list = cacheclient.fetchLiveList("mylist");  
     *         list.clear();                                     
     *         list.add("String value one");                     
     *                                                           
     *         List list2 = cacheclient.fetchLiveList("mylist"); 
     *         list2.contains("String value one");   
     *                                                           
     *         list.add("String value two");                   
     *         list2.contains("String value two"); 
     *                                                           
     *         list2.add("String value three");                   
     *         list.contains("String value three");   
     *     }                                                     
     * }</pre>
     * <p>
     * @param key The key to the List instance.
     * @return A java.util.List object. If the List object does not exist, an empty List is returned.
     */
    public List fetchLiveList(String key) {
        return redisson.getList(prependAppName(key));
    }
    
    /**
     * Retrieve or create a cached live Map object. Changes to the Map are propagated to 
     * all object instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {   
     *         Map map = cacheclient.fetchLiveMap("mymap");       
     *         map.clear();                                       
     *         map.put("key1", "value1");                         
     *                                                            
     *         Map map2 = cacheclient.fetchLiveMap("mymap");      
     *         map2.containsKey("key1");              
     *                                                            
     *         map.put("key2", "value2");                         
     *         map2.containsKey("key2");              
     *                                                            
     *         map2.put("key3", "value3");                        
     *         map.containsKey("key3");               
     *     }                                                     
     * }</pre>
     * <p>
     * @param key The key to the Map instance.
     * @return A java.util.Map object. If the Map object does not exist, an empty Map is returned.
     */
    public Map fetchLiveMap(String key) {
        return redisson.getMap(prependAppName(key));
    }

    /**
     * Retrieve or create a cached live Queue object. Changes to the Queue are propagated to 
     * all object instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {   
     *         Queue queue = cacheclient.fetchLiveQueue("myqueue");    
     *         queue.clear();                                          
     *         queue.add("String value one");                          
     *         queue.add("String value two");                          
     *                                                                 
     *         Queue queue2 = cacheclient.fetchLiveQueue("myqueue");  
     *         queue2.contains("String value one");        
     *         queue2.contains("String value two");        
     *                                                                 
     *         queue.add("String value three");                        
     *         queue2.contains("String value three");     
     *                                                                
     *         queue.remove();                                        
     *         !queue2.contains("String value one");      
     *                                                                
     *         queue2.remove();                                       
     *         !queue.contains("String value two");       
     *     }                                                     
     * }</pre>
     * <p>
     * @param key The key to the Queue instance.
     * @return A java.util.Queue object. If the Queue object does not exist, an empty 
     *         Queue is returned.
     */
    public Queue fetchLiveQueue(String key) {
        return redisson.getQueue(prependAppName(key));
    }

    /**
     * Retrieve or create a cached live Set object. Changes to the Set are propagated to 
     * all object instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {   
     *         Set set = cacheclient.fetchLiveSet("myset");     
     *         set.clear();                                     
     *         set.add("String value one");                     
     *                                                          
     *         Set set2 = cacheclient.fetchLiveSet("myset");    
     *         set2.contains("String value one");   
     *         !set2.contains("String value two");
     *                                                          
     *         set.add("String value two");                   
     *         set2.contains("String value two"); 
     *                                                          
     *         set2.add("String value three");                   
     *         set.contains("String value three");   
     *     }                                                     
     * }</pre>
     * <p>
     * @param key The key to the Set instance.
     * @return A java.util.Set object. If the Set object does not exist, an empty Set 
     *         is returned.
     */
    public Set fetchLiveSet(String key) {
        return redisson.getSet(prependAppName(key));
    }
    
    /**
     * Retrieve or create a cached live SortedSet object. Changes to the SortedSet are 
     * propagated to all object instances.
     * <p>
     * Example
     * <pre>{@code
     *     try (CacheClient cacheclient = new CacheClient()) {   
     *         Set set = cacheclient.fetchLiveSortedSet("myset");     
     *         set.clear();                                     
     *         set.add("String value one");                     
     *                                                          
     *         Set set2 = cacheclient.fetchLiveSortedSet("myset");    
     *         set2.contains("String value one");   
     *         !set2.contains("String value two");
     *                                                          
     *         set.add("String value two");                   
     *         set2.contains("String value two"); 
     *                                                          
     *         set2.add("String value three");                   
     *         set.contains("String value three");   
     *     }                                                     
     * }</pre>
     * <p>
     * @param key The key to the SortedSet instance.
     * @return A java.util.SortedSet object. If the SortedSet object does not exist, an 
     *         empty SortedSet is returned.
     */
    public SortedSet fetchLiveSortedSet(String key) {
        return redisson.getSortedSet(prependAppName(key));
    }

    /**
     * Retrieve all keys present in the cache.
     * <p>
     * @return An Iterable to String values.
     */
    public Iterable<String> getAllKeys() {
        RKeys rkeys = redisson.getKeys();
        return rkeys.getKeys();
    }
    
    /**
     * Retrieve keys using a string pattern. Pattern utilizes the glob style, e.g.
     * <br>h?llo subscribes to hello, hallo and hxllo
     * <br>h*llo subscribes to hllo and heeeello
     * <br>h[ae]llo subscribes to hello and hallo, but not hillo
     * <p>
     * @param pattern The glob pattern string.
     * @return An Iterable to String values.
     */
    public Iterable<String> getKeysByPattern(String pattern) {
        RKeys rkeys = redisson.getKeys();
        return rkeys.getKeysByPattern(prependAppName(pattern));
    }
    
    /**
     * Deletes multiple cached objects by key name.
     * <p>  
     * @param keys String array of keys.
     * @return Number of objects deleted.
     */
    public long delete(String[] keys) {
        RKeys rkeys = redisson.getKeys();
        String[] newkeys = new String[keys.length];
        for (int i = 0; i < keys.length; i++) {
            newkeys[i] = prependAppName(keys[i]);
        }
        return rkeys.delete(newkeys);
    }
    
    /**
     * Deletes objects using a string pattern. Pattern utilizes the glob style, e.g.
     * <br>h?llo subscribes to hello, hallo and hxllo
     * <br>h*llo subscribes to hllo and heeeello
     * <br>h[ae]llo subscribes to hello and hallo, but not hillo
     * <p>
     * @param pattern The glob pattern string.
     * @return Number of objects deleted.
     */
    public long deleteByPattern(String pattern) {
        RKeys rkeys = redisson.getKeys();
        return rkeys.deleteByPattern(prependAppName(pattern));
    }
    
    /**
     * Creates a cache key from the supplied appname, key and object class name.
     * <p>
     * @param key A client provided key.
     * @param c The object class.
     * @return A String value with the structure {key}:{classname}
     */
    private String createClassKey(String key, Class c) {
        StringBuilder sb = new StringBuilder();
        sb.append(prependAppName(key));
        sb.append(":");
        sb.append(c.getName());
        return sb.toString();
    }
    
    /**
     * Add the application name to the key if available.
     * @param key A client provided key.
     * @return
     */
    private String prependAppName(String key) {
        if (appname.isEmpty()) {
            return key;
        }
        else {
            return appname + key;
        }
    }

    private void close() {
        if (redisson != null) {
            redisson.shutdown();
        }
    }

    /**
     * Retrieve stats for all objects handled by this CacheClient instance.
     * <p>
     * @return
     */
    public Map<String, CacheObjectStats> getAllStats() {
        return statsmap;
    }
    
    /**
     * Retrieve stats for the specified object handled by this CacheClient instance.
     * <p>
     * @param key Key identifying the cached object.
     * @return
     */
    public CacheObjectStats getStat(String key) {
        return statsmap.get(key);
    }

    /**
     * Used for testing
     * @return The time-to-live in milliseconds.
     */
    public long getTimeToLiveMs() {
        return timeToLiveMs;
    }

    /**
     * Used for testing
     */
    public static void setTestmode(boolean mode) {
        testmode = mode;
    }
}
