package com.aig.lnr.cache;

import java.time.Instant;

/**
 * Holds the statistics for an object being cached by the CacheClient instance. 
 * <p>
 * @author Will Tan
 * <br>02/12/21 Will Tan    - Initial version.
 */
public class CacheObjectStats {
    private String key;
    private Instant starttime;
    private int hitcount;
    private int misscount;

    public CacheObjectStats(String key, Instant starttime) {
        this.key = key;
        this.starttime = starttime;
    }

    /**
     * Retrieve the key of the object for which stats are captured.
     * <p>
     * @return
     */
    public String getKey() {
        return key;
    }

    /**
     * Return the elapsed time in milliseconds. The object start time begins when it is
     * first referenced by a store or fetch operation. This elapsed time spans the period 
     * between the start time and the current time and allows the recorded hit and miss 
     * counts to be attributable to a duration of time. 
     * <p>
     * @return
     */
    public Long getElapsedMillis() {
        Instant now = Instant.now();
        return now.toEpochMilli() - starttime.toEpochMilli();
    }

    /**
     * Retrieve the cache hit count.
     * <p>
     * @return
     */
    public int getHitCount() {
        return hitcount;
    }

    /**
     * Increments the hit count by 1.
     */
    public void incrementHitCount() {
        this.hitcount++;
    }

    /**
     * Retrieve the cache miss count.
     * <p>
     * @return
     */
    public int getMissCount() {
        return misscount;
    }

    /**
     * Increments the miss count by 1.
     * <p>
     * @param misscount
     */
    public void incrementMissCount() {
        this.misscount++;
    }
}
