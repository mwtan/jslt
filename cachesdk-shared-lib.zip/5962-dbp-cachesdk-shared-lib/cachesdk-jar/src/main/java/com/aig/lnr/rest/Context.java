package com.aig.lnr.rest;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

import org.apache.commons.codec.binary.Base64;
import org.glassfish.jersey.media.multipart.BodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;

/**
 * A context object holding attributes needed for calling the RESTServiceClient.
 * <p>
 * @author Will Tan
 * <br>06/01/20 Will Tan    - Default path to an empty string.
 */
public class Context {
    private static final int CONST_DEFAULT_MAPSIZE = 7;
    public static final String TYPE_XML = MediaType.APPLICATION_XML;
    public static final String TYPE_JSON = MediaType.APPLICATION_JSON;
    public static final String METHOD_GET = "GET";
    public static final String METHOD_PUT = "PUT";
    public static final String METHOD_POST = "POST";
    private String target;
    private String path = "";
    private Map<String, String> queryMap;
    private Map<String, String> headerMap;
    private String authorization;
    private String type;
    private String method;
    private String requestObject;
    private Form formObject;
    private FormDataMultiPart formMultiPart;
    
    public Context(){
        queryMap = new LinkedHashMap<>(CONST_DEFAULT_MAPSIZE);
        headerMap = new LinkedHashMap<>(CONST_DEFAULT_MAPSIZE);
    }
    
    // Request target
    public void setTarget(String requestTarget) {
        target = requestTarget;
    }
    public String getTarget() {
        return target;
    }

    // Request path
    public void setPath(String requestPath) {
        path = requestPath;
    }
    public String getPath() {
        return path;
    }

    // Query parms
    public void setQueryParameters(Map<String, String> requestParms) {
        queryMap = requestParms;
    }
    public Map<String, String> getQueryParameters() {
        return queryMap;
    }
    public void addQueryParameter(String name, String value) {
        queryMap.put(name, value);
    }
    public void removeQueryParameter(String name) {
        queryMap.remove(name);
    }

    // Header parms
    public void setHeaderParameters(Map<String, String> headerParms) {
        headerMap = headerParms;
    }
    public Map<String, String> getHeaderParameters() {
        return headerMap;
    }
    public void addHeaderParameter(String name, String value) {
        headerMap.put(name, value);
    }
    public void removeHeaderParameter(String name) {
        headerMap.remove(name);
    }

    // Authorization
    public void setAuthorization(String requestAuthorization) {
        authorization = requestAuthorization;
    }
    public void setAuthorization(String user, String password) {
        String userpass = user + ":" + password;
        authorization = "Basic " + new String(new Base64().encode(userpass.getBytes()));
    }
    public String getAuthorization() {
        return authorization;
    }

    // Content type
    public String getType() {
        return type;
    }
    public void setType(String type) {
        switch (type) {
            case "XML": 
                this.type = Context.TYPE_XML; 
                break;
            case "JSON": 
                this.type = Context.TYPE_JSON; 
                break;
            case "JSON2XML": 
                this.type = Context.TYPE_JSON; 
                break;
            default:
                this.type = type;
        }
    }

    // Method
    public String getMethod() {
        return method;
    }
    public void setMethod(String method) {
        this.method = method;
    }

    // Form object
    public Form getFormObject() {
        return formObject;
    }
    // Form parms
    public void addFormParameter(String name, String value) {
        if (formObject == null) {
            formObject = new Form();
        }
        formObject.param(name, value);
    }

    // Multipart form object
    public FormDataMultiPart getMultiPartFormObject() {
        return formMultiPart;
    }
    // Multipart form parms
    public void addMultiPartFormParameter(String name, String value) {
        if (formMultiPart == null) {
            formMultiPart = new FormDataMultiPart();
        }
        formMultiPart.field(name, value);
    }
    public void addMultiPartFormBodyPart(BodyPart bodypart) {
        formMultiPart.bodyPart(bodypart);
    }
    
    // Request object
    public String getRequestObject() {
        return requestObject;
    }
    public void setRequestObject(String requestObject) {
        this.requestObject = requestObject;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Target:" + target + "\n");
        sb.append("Path:" + path + "\n");
        sb.append("Parameters:" + queryMap.toString());
        return sb.toString();
    }
}
