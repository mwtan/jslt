package com.aig.lnr.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

import com.aig.exception.CommonRuntimeException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A general purpose service client that facilitates calling REST services.
 * <p>
 * @author Will Tan
 * <br>09/16/20 Will Tan    - Customized version for Cache SDK.
 */
public class ServiceClient {
    private Context context;
    private int responseStatus;
    private Builder ib;
    
    /**
     * Construct the service client using the supplied context object.
     * <p>
     * @param context The Context object.
     */
    public ServiceClient(Context context) {
        this.context = context;
        init(context);
    }

    /**
     * Initializes the ServiceClient with a Context object.
     * <p>
     * @param context The Context object.
     */
    public final void init(Context context) {
        try {
            ib = prepareRequest(context);
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception creating ServiceClient - " + e.getMessage(), e);
        }
    }
    
    /**
     * Creates an Invocation Builder for the service call.
     * <p>
     * @param context The Context object.
     * @return A Builder object.
     */
    Builder prepareRequest(Context context) {
        Client client = ClientBuilder.newClient();
        WebTarget tgt = client.target(context.getTarget());
        tgt = tgt.path(context.getPath());
        // Register the MultiPart MessageBodyWriter
        if (context.getMultiPartFormObject() != null) {
            tgt.register(MultiPartFeature.class);
        }
        // Add query parameters
        Map<String, String> queryParms = context.getQueryParameters();
        for (Entry<String, String> entry : queryParms.entrySet()) {
            tgt = tgt.queryParam(entry.getKey(), entry.getValue());
        }
        // Add auth
        Builder ibuilder = tgt.request(context.getType());
        ibuilder.header(HttpHeaders.AUTHORIZATION, context.getAuthorization());
        // Add headers
        Map<String, String> headers = context.getHeaderParameters();
        for (Entry<String, String> entry : headers.entrySet()) {
            ibuilder.header(entry.getKey(), entry.getValue());
        }
        return ibuilder;
    }
    
    /**
     * Call the REST service using GET.
     * <p>
     * @return The response string.
     */
    public String getRequest() {
        try {
            Response res = ib.get();
            responseStatus = res.getStatus();
            return res.readEntity(String.class);
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception calling REST service (GET)." + e.getMessage(), e);
        }
    }

    /**
     * Call the REST service using GET but return complete response.
     * <p>
     * @return The Response object.
     */ 
    public Response getRequestWithResponse() {
        try {
            Response res = ib.get();
            responseStatus = res.getStatus();
            return res;
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception calling REST service (GET)." + e.getMessage(), e);
        }
    }

    /**
     * Call the REST service using PUT.
     * <p>
     * @return The response string.
     */
    public String putRequest() {
        Response res = putRequestWithResponse();
        return res.readEntity(String.class);
    }
    
    /**
     * Call the REST service using PUT, returning the Response object.
     * <p>
     * @return The Response object.
     */
    public Response putRequestWithResponse() {
        try {
            Response res;
            // Add request object if available
            if (context.getRequestObject() != null) {
                res = ib.put(Entity.entity(context.getRequestObject(), context.getType()));
            }
            else {
                res = ib.put(Entity.entity(context.getQueryParameters(), context.getType()));
            }
            responseStatus = res.getStatus();
            return res;
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception calling REST service (PUT)." + e.getMessage(), e);
        }
    }
    
    /**
     * Call the REST service using POST.
     * <p>
     * @return The response string.
     */
    public String postRequest() {
        Response res = postRequestWithResponse();
        return res.readEntity(String.class);
    }
    
    /**
     * Call the REST service using POST.
     * <p>
     * @return The Response object.
     */
    public Response postRequestWithResponse() {
        try {
            Response res;
            // Add form object if available
            if (context.getFormObject() != null) {
                res = ib.post(Entity.form(context.getFormObject()), Response.class);
            }
            // Add multipart form object if available
            else if (context.getMultiPartFormObject() != null) {
                FormDataMultiPart fdmp = context.getMultiPartFormObject();
                res = ib.post(Entity.entity(fdmp, fdmp.getMediaType()));
            }
            // Add request object if available
            else if (context.getRequestObject() != null) {
                res = ib.post(Entity.entity(context.getRequestObject(), context.getType()));
            }
            // Add query parameters
            else {
                res = ib.post(Entity.entity(context.getQueryParameters(), context.getType()));
            }
            responseStatus = res.getStatus();
            return res;
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception calling REST service (POST)." + e.getMessage(), e);
        }
    }
    
    /**
     * Call the REST service using DELETE.
     * <p>
     * @return The response string.
     */
    public String deleteRequest() {
        Response res = deleteRequestWithResponse();
        return res.readEntity(String.class);
    }
    
    /**
     * Call the REST service using DELETE, returning the Response object.
     * <p>
     * @return The Response object.
     */
    public Response deleteRequestWithResponse() {
        try {
            Response res = ib.delete();
            responseStatus = res.getStatus();
            return res;
        }
        catch (RuntimeException e) {
            throw new CommonRuntimeException("Exception calling REST service (DELETE)." + e.getMessage(), e);
        }
    }
    
    /**
     * Returns the response status of the last service call.
     * <p>
     * @return integer The response status, e.g. 200
     */
    public int getResponseStatus() {
        return responseStatus;
    }

    /**
     * Used for testing.
     * <p>
     * @param status int value
     */
    public void setResponseStatus(int status) {
        responseStatus = status;
    }
    
    /**
     * Utility method to produce a JsonNode object from a JSON string. The JsonNode object
     * can then be used to traverse the JSON structure. 
     * <p>
     * @param json The JSON string.
     * @return A JsonNode object.
     * @throws IOException Exception when mapping the JSON.
     */
    public static JsonNode toJsonNode(String json) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readTree(json);
    }
}
