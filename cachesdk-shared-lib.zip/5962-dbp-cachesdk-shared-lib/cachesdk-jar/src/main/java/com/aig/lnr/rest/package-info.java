package com.aig.lnr.rest;

/**
 * Package containing REST client classes.
 * <p>
 * @author Will Tan
 */
