package com.aig.lnr.secret;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aig.exception.CommonRuntimeException;
import com.aig.lnr.util.AbstractServiceRetry;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Abstract class implemented by a secret provider.
 * <p>
 * @author Will Tan
 * <br>04/20/20 Will Tan    - Renamed log to LOGGER.
 * <br>07/01/20 Will Tan    - Extend AbstractRetryable.
 */
public abstract class AbstractSecretProvider extends AbstractServiceRetry {
    protected Logger LOGGER;
    protected static boolean testmode;
    protected static String  testmodeObjectString = "";
    protected static boolean testmodeThrowException;
    protected static boolean testmodeThrowExecutionException;

    public AbstractSecretProvider() {
        super();
        LOGGER = LoggerFactory.getLogger(this.getClass());
    }
    
    /**
     * Retrieves the secrets from the secrets provider as a JSON string.
     * <p>
     * @param secretkey The secret key.
     * @return The secret string.
     */
    public abstract String getSecretJson(String secretkey);
    
    /**
     * Retrieves the secrets for the specified secret key.
     * <p>
     * @param secretkey The secret key.
     * @return A Map for retrieving secrets by key value.
     */
    public abstract Map<String, String> getSecrets(String secretkey);
    
    /**
     * Utility method for converting a JSON string to a Map object.
     * <p>
     * @param jsonstring The json string.
     * @return A Map object.
     */
    public Map<String, String> jsonToMap(String jsonstring) {
        try {
            return new ObjectMapper().readValue(jsonstring, HashMap.class);
        }
        catch (IOException e) {
            throw new CommonRuntimeException("[AbstractSecretProvider] Error reading JSON: " + jsonstring, e);
        }
    }

    // Package access methods for testing.
    public static void setTestmode(boolean mode) {
        testmode = mode;
        testmodeObjectString = "";
        testmodeThrowException = false;
        testmodeThrowExecutionException = false;
    }
    public static void setTestmodeObjectString(String str) {
        testmodeObjectString = str;
    }
    public static void setTestmodeThrowException(boolean throwException) {
        testmodeThrowException = throwException;
    }
    static void setTestmodeThrowExecutionException(boolean throwExecutionException) {
        testmodeThrowExecutionException = throwExecutionException;
    }
}
