package com.aig.lnr.secret;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aig.exception.CommonRuntimeException;
import com.aig.lnr.util.ConfigManager;

/**
 * Retrieves secrets using the configured secrets provider type.
 * e.g. system.secret.provider=HASHICORPVAULT
 * <p>
 * @author Will Tan
 * <br>09/16/20 Will Tan    - Customized version for Cache SDK.
 * <br>09/18/20 Will Tan    - Use VaultSecretProvider if provider not specified.
 * <br>09/18/20 Will Tan    - Cache secrets.
 * <br>11/06/20 Will Tan    - Use HASHICORPVAULT as default if provider not specified.
 */
public final class SecretsManager {
    public static final String CONST_SECRET_PROVIDER_PROP       = "secretsmanager.provider";
    public static final String CONST_SECRET_PROVIDER_AWS        = "AWSSECRETSMANAGER";
    public static final String CONST_SECRET_PROVIDER_VAULT      = "HASHICORPVAULT";
    // The Singleton SecretsManager reference that is lazily instantiated.
    private static SecretsManager sm;
    private AbstractSecretProvider provider; 
    private Map<String, Map<String, String>> cache = new HashMap<>();
    private static final Logger LOGGER = LoggerFactory.getLogger(SecretsManager.class);
    
    // Prevent construction.
    private SecretsManager() {
        String providertype = ConfigManager.getProperty(CONST_SECRET_PROVIDER_PROP, "");
        if (isBlank(providertype)) {
            providertype = SecretsManager.CONST_SECRET_PROVIDER_VAULT;
            LOGGER.info("Using default secret provider {}", providertype);
        }
        if (providertype.equals(CONST_SECRET_PROVIDER_VAULT)) {
            provider = new VaultSecretProvider();
        }
        else {
            throw new CommonRuntimeException("[SecretsManager] Invalid secret provider type: " + providertype);
        }
    }

    /**
     * Retrieves the singleton SecretsManager object.
     * <p>
     * @return The SecretsManager Singleton instance.
     */
    public static SecretsManager getReference() {
        if (sm == null) {
            sm = new SecretsManager();
        }
        return (sm);
    }

    /**
     * Retrieve secrets from the configured secrets provider using the supplied secret key.
     * Secrets are cached for each secretkey value.
     * <p>
     * @param secretkey The secret key or grouping of secret key/values.
     * @return A Map object for retrieving secret values by a key name.
     */
    public Map<String, String> getSecrets(String secretkey) {
        if (cache.containsKey(secretkey)) {
            return cache.get(secretkey);
        }
        else {
            Map<String, String> secretmap = provider.getSecrets(secretkey);
            cache.put(secretkey, secretmap);
            return secretmap;
        }
    }

    public static boolean isBlank(String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    // Methods for testing.
    public static void reset() {
        sm = null;
    }
    static AbstractSecretProvider getProvider() {
        return sm.provider;
    }
}
