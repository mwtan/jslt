package com.aig.lnr.secret;

import java.io.IOException;
import java.util.Map;

import com.aig.exception.CommonRuntimeException;
import com.aig.lnr.rest.Context;
import com.aig.lnr.rest.ServiceClient;
import com.aig.lnr.util.ConfigManager;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Enables secrets to be retrieved from HashiCorp Vault using a secret key.
 * <p>
 * @author Will Tan
 * <br>09/16/20 Will Tan    - Customized version for Cache SDK.
 * <br>11/06/20 Will Tan    - Enable retrieval of Vault properties using specified or default key names.
 * <br>12/14/20 Will Tan    - Removed duplicated literals.
 */
public class VaultSecretProvider extends AbstractSecretProvider {
    private static final String CONST_DEFAULT_PROPERTY = "Using default property ";
    private static final String CONST_MISSING_VALUE = "Missing value for property ";
    private static final int CONST_10 = 10;
    // VaultSecretProvider property key names
    public static final String CONST_VAULT_URL_PROP_KEY         = "system.vault.url.property";
    public static final String CONST_VAULT_APIKEY_PROP_KEY      = "system.vault.apikey.property";
    public static final String CONST_VAULT_ROLEID_PROP_KEY      = "system.vault.roleid.property";
    public static final String CONST_VAULT_SECRETID_PROP_KEY    = "system.vault.secretid.property";
    // Default property key names
    public static final String CONST_DEFAULT_URL_PROP_KEY       = "vault.base.url";
    public static final String CONST_DEFAULT_APIKEY_PROP_KEY    = "vault.api.key";
    public static final String CONST_DEFAULT_ROLEID_PROP_KEY    = "vault.role.id";
    public static final String CONST_DEFAULT_SECRETID_PROP_KEY  = "vault.secret.id";
    // Vault API parms
    public static final String CONST_VAULT_APIKEY_PARM          = "apikey";
    public static final String CONST_VAULT_ROLEID_PARM          = "X-Role-Id";
    public static final String CONST_VAULT_SECRETID_PARM        = "X-Secret-Id";
    private String vaulturl;
    private String vaultapikey;
    private String vaultroleid;
    private String vaultsecretid;

    public VaultSecretProvider() {
        super();
        // Retrieve property key names
        String urlprop = ConfigManager.getProperty(CONST_VAULT_URL_PROP_KEY);
        if (SecretsManager.isBlank(urlprop)) {
            urlprop = CONST_DEFAULT_URL_PROP_KEY;
            LOGGER.debug(CONST_DEFAULT_PROPERTY + CONST_DEFAULT_URL_PROP_KEY);
        }
        String apikeyprop = ConfigManager.getProperty(CONST_VAULT_APIKEY_PROP_KEY);
        if (SecretsManager.isBlank(apikeyprop)) {
            apikeyprop = CONST_DEFAULT_APIKEY_PROP_KEY;
            LOGGER.debug(CONST_DEFAULT_PROPERTY + CONST_DEFAULT_APIKEY_PROP_KEY);
        }
        String roleidprop = ConfigManager.getProperty(CONST_VAULT_ROLEID_PROP_KEY);
        if (SecretsManager.isBlank(roleidprop)) {
            roleidprop = CONST_DEFAULT_ROLEID_PROP_KEY;
            LOGGER.debug(CONST_DEFAULT_PROPERTY + CONST_DEFAULT_ROLEID_PROP_KEY);
        }
        String secretidprop = ConfigManager.getProperty(CONST_VAULT_SECRETID_PROP_KEY);
        if (SecretsManager.isBlank(secretidprop)) {
            secretidprop = CONST_DEFAULT_SECRETID_PROP_KEY;
            LOGGER.debug(CONST_DEFAULT_PROPERTY + CONST_DEFAULT_SECRETID_PROP_KEY);
        }
        // Retrieve Vault property values
        vaulturl = ConfigManager.getProperty(urlprop);
        if (SecretsManager.isBlank(vaulturl)) {
            throw new CommonRuntimeException(CONST_MISSING_VALUE + urlprop);
        }
        vaultapikey = ConfigManager.getProperty(apikeyprop);
        if (SecretsManager.isBlank(vaultapikey)) {
            throw new CommonRuntimeException(CONST_MISSING_VALUE + apikeyprop);
        }
        vaultroleid = ConfigManager.getProperty(roleidprop);
        if (SecretsManager.isBlank(vaultroleid)) {
            throw new CommonRuntimeException(CONST_MISSING_VALUE + roleidprop);
        }
        vaultsecretid = ConfigManager.getProperty(secretidprop);
        if (SecretsManager.isBlank(vaultsecretid)) {
            throw new CommonRuntimeException(CONST_MISSING_VALUE + secretidprop);
        }
    }
    
    @Override
    public String getSecretJson(String secretKey) {
        Context ctx = new Context();
        ctx.setTarget(vaulturl);
        ctx.setPath(secretKey);
        ctx.setType("JSON");
        ctx.addHeaderParameter(CONST_VAULT_APIKEY_PARM, vaultapikey);
        ctx.addHeaderParameter(CONST_VAULT_ROLEID_PARM, vaultroleid);
        ctx.addHeaderParameter(CONST_VAULT_SECRETID_PARM, vaultsecretid);
        String jsonstr = retryDoServiceCall(new ServiceClient(ctx));
        if (jsonstr == null || jsonstr.isEmpty()) {
            throw new CommonRuntimeException(getSecretNameLabel(secretKey) + " - null secret result.");
        }
        return jsonstr;
    }
    
    private static String getSecretNameLabel(String secretName) {
        return "[VaultSecretProvider] Secretname: " + secretName;
    }

    @Override
    public String doServiceCall(ServiceClient client) {
        if (!testmode) {
            return client.getRequest();
        }
        else {
            if (testmodeThrowException) {
                throw new CommonRuntimeException("Test RuntimeException.");
            }
            else if (testmodeThrowExecutionException) {
                throw new VerifyError("Test ExecutionException.");
            }
            else {
                return testmodeObjectString;
            }
        }
    }

    /**
     * Retrieves secrets from Vault using the secretkey. This is normally the vault mount path.
     * It returns a Map of key/values under the secret/data node of the returned JSON.
     */
    @Override
    public Map<String, String> getSecrets(String secretkey) {
        try {
            String json = getSecretJson(secretkey);
            if ((json != null && !json.isEmpty()) &&
                (json.contains("Bad Request") || json.contains("400"))) {
                throw new CommonRuntimeException("[VaultSecretProvider] Bad response from Vault. vaulturl: " + 
                        vaulturl + " vaultapikey:" + vaultapikey.substring(0, CONST_10) + "...[truncated] vaultroleid:" + 
                        vaultroleid.substring(0, CONST_10) + "...[truncated] vaultsecretid:" + 
                        vaultsecretid.substring(0, CONST_10) + "...[truncated] JSON:" + json);
            }
            JsonNode rootnode = new ObjectMapper().readTree(json);
            JsonNode secretnode = rootnode.path("secret");
            JsonNode datanode = secretnode.path("data");
            String secretstr = datanode.toString();
            return jsonToMap(secretstr);
        }
        catch (IOException e) {
            throw new CommonRuntimeException("[VaultSecretProvider] Error parsing secret response.", e);
        }
        catch (CommonRuntimeException e1) {
            throw e1;
        }
    }
}
