package com.aig.lnr.util;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import com.aig.exception.CommonException;
import com.aig.exception.CommonRuntimeException;
import com.aig.exception.RetryableException;
import com.aig.lnr.rest.ServiceClient;
import com.github.rholder.retry.RetryException;
import com.github.rholder.retry.Retryer;
import com.github.rholder.retry.RetryerBuilder;
import com.github.rholder.retry.StopStrategies;
import com.github.rholder.retry.WaitStrategies;

/**
 * Enables retries of service calls.
 * <p>
 * @author Will Tan
 * <br>07/01/20 Will Tan    - Initial version.
 */
public abstract class AbstractServiceRetry {
    public static final String SYS_RETRYTIMES                   = "system.retrytimes";
    public static final String SYS_RETRYWAITMS                  = "system.retrywaitms";
    public static final String SYS_RETRYMAXWAITMS               = "system.retrymaxwaitms";
    public static final int CONST_DEFAULT_RETRYMAXWAITMS        = 120_000;
    public static final int CONST_DEFAULT_RETRYWAITMS           = 6_000;
    public static final int CONST_DEFAULT_RETRYTIMES            = 6;
    protected int retrytimes = CONST_DEFAULT_RETRYTIMES;
    protected long retrywaitms = CONST_DEFAULT_RETRYWAITMS;
    protected long retrymaxwaitms = CONST_DEFAULT_RETRYMAXWAITMS;
    protected LogRetryListener listener;

    /**
     * Default constructor.
     */
    public AbstractServiceRetry() {
        // retrytimes
        String retrytimesstr = ConfigManager.getProperty(SYS_RETRYTIMES);
        if (retrytimesstr != null && !retrytimesstr.isEmpty()) {
            retrytimes = Integer.parseInt(retrytimesstr);
        }
        // retrywaitms
        String retrywaitmsstr = ConfigManager.getProperty(SYS_RETRYWAITMS);
        if (retrywaitmsstr != null && !retrywaitmsstr.isEmpty()) {
            retrywaitms = Long.parseLong(retrywaitmsstr);
        }
        // retrymaxwaitms
        String retrymaxwaitmsstr = ConfigManager.getProperty(SYS_RETRYMAXWAITMS);
        if (retrymaxwaitmsstr != null && !retrymaxwaitmsstr.isEmpty()) {
            retrymaxwaitms = Long.parseLong(retrymaxwaitmsstr);
        }
        listener = new LogRetryListener();
    }

    /**
     * Make the service call with retry handling.
     * <p>
     * @param client The ServiceClient.
     * @return String result from the service call.
     */
    public String retryDoServiceCall(ServiceClient client) {
        Retryer<String> retryer = RetryerBuilder.<String>newBuilder()
                .retryIfExceptionOfType(RetryableException.class)
                .retryIfExceptionOfType(CommonException.class)
                .retryIfRuntimeException()
                .withWaitStrategy(WaitStrategies.fibonacciWait(retrywaitms, retrymaxwaitms, TimeUnit.MILLISECONDS))
                .withStopStrategy(StopStrategies.stopAfterAttempt(retrytimes))
                .withRetryListener(listener)
                .build();
        try {
            return retryerCall(retryer, client);
        }
        catch (RetryException re) {
            throw new CommonRuntimeException("Retryer failed after " + retrytimes + " attempts.\n"
                    + listener.getStackTrace(), re);
        }
        catch (ExecutionException ee) {
            throw new CommonRuntimeException("Retryer failed.\n" + listener.getStackTrace(), ee);
        }
    }
    
    /**
     * Call the service.
     * <p>
     * @param retryer The Retryer.
     * @param client The ServiceClient.
     * @return String result from the service call.
     * @throws ExecutionException Exception calling service.
     * @throws RetryException Exception during retry.
     */
    public String retryerCall(Retryer<String> retryer, ServiceClient client) 
            throws ExecutionException, RetryException {
        return retryer.call( () -> doServiceCall(client));
    }

    /**
     * The method that implements the retried service call.
     * <p>
     * @param client The ServiceClient.
     * @return String result from the service call.
     */
    public abstract String doServiceCall(ServiceClient client);
    
    // Methods for unit tests
    public int getRetrytimes() {
        return retrytimes;
    }
    public long getRetrywaitms() {
        return retrywaitms;
    }
    public long getRetrymaxwaitms() {
        return retrymaxwaitms;
    }
    public void setRetry(int retrytimes, long retrywaitms, long retrymaxwaitms) {
        this.retrytimes = retrytimes;
        this.retrywaitms = retrywaitms;
        this.retrymaxwaitms = retrymaxwaitms;
    }
}
