package com.aig.lnr.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * Customized version of ConfigManager that retrieves values from system properties.
 * <p>
 * @author Will Tan
 * <br>09/16/20 Will Tan    - Customized version for Cache SDK.
 * <br>11/13/20 Will Tan    - Modified to load environment variables.
 * <br>12/04/20 Will Tan    - Sonar changes.
 * <br>12/21/20 Will Tan    - Load application.properties. Added getBooleanProperty.
 * <br>01/27/21 Will Tan    - Load application.properties using getSystemResourceAsStream.
 * <br>01/28/21 Will Tan    - Load application.properties using current classloader.
 */
public final class ConfigManager {
    private static Properties prop;
    private static String propfile = "application.properties";
    
    static {
        initialize();
    }

    // Prevent instantiation
    private ConfigManager() {
        // No implementation
    }
    
    public static void initialize() {
        prop = new Properties();
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        try (final InputStream streamresource = classLoader.getResourceAsStream(propfile)) {
            if (streamresource != null) {
                prop.load(streamresource);
            }
            else {
                try (final InputStream streamfile = new FileInputStream(propfile)) {
                    prop.load(streamfile);
                }
            }
        }
        catch (IOException e) {
            // Ignore
        }
        // Load system properties
        prop.putAll(System.getProperties());
        // Insert environment variables
        Iterator<Entry<String, String>> it = System.getenv().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, String> entry = it.next();
            prop.put(entry.getKey(), entry.getValue());
        }
    }
    
    /**
     * Retrieves the value of the named property key.
     * @param inPropertyKey The property key.
     * @return A value string. Null if the property does not exist.
     */
    public static String getProperty(String key) {
        return prop.getProperty(key);
    }

    /**
     * Retrieves the value of the named property key. The default value is returned if
     * the property does not exist.
     * @param key The property key.
     * @param defaultVal The default value.
     * @return A value string. The default value is returned if the property does not exist.
     */
    public static String getProperty(String key, String defaultVal) {
        String val = prop.getProperty(key);
        if (val == null) {
            val = defaultVal;
        }
        return val;
    }

    /**
     * Retrieves a property and converts it to a boolean if it is not null.
     * The Boolean.valueOf method is used to convert the property string value and 
     * should therefore have values of "true" or a value other than "true", e.g. "false".
     * If the requested property is null (i.e. not found), defaultVal is returned.
     * <p>   
     * @param key - the key of the property to retrieve.
     * @param defaultVal - the default value returned if the property is not found.
     * @return A boolean true or false.
     */
    public static boolean getBooleanProperty(String key, boolean defaultVal) {
        String val = prop.getProperty(key);
        if (val == null) {
            return defaultVal;
        }
        return Boolean.parseBoolean(val);
    }

    // Used for testing
    public static void setPropfile(String propfile) {
        ConfigManager.propfile = propfile;
    }
}
