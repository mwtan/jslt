package com.aig.lnr.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.github.rholder.retry.Attempt;
import com.github.rholder.retry.RetryListener;

/**
 * Listener class used to log retry messages. 
 * <p>
 * @author Will Tan 
 */
public class LogRetryListener implements RetryListener {
    private static final String RETRYER_FAILED  = "Retryer[FAILED] Attempt: ";
    private static final String RETRYER_SUCCESS = "Retryer[SUCCESS] After attempt: ";
    private static final String RETRYER_DELAY   = " with total delay ";
    protected Logger log;
    protected String stacktrace;

    public LogRetryListener() {
        log = LoggerFactory.getLogger(this.getClass());
    }
    
    @Override
    public <V> void onRetry(Attempt<V> attempt) {
        if (attempt.hasException()) {
            Throwable t = attempt.getExceptionCause();
            stacktrace = org.apache.commons.lang.exception.ExceptionUtils.getStackTrace(t);
            log.error(RETRYER_FAILED + attempt.getAttemptNumber() + RETRYER_DELAY
                    + attempt.getDelaySinceFirstAttempt() + "ms.", t);
        }
        else {
            if (attempt.getAttemptNumber() > 1) {
                String msg = RETRYER_SUCCESS + attempt.getAttemptNumber() + RETRYER_DELAY
                        + attempt.getDelaySinceFirstAttempt() + "ms.";
                if (attempt.hasResult() && attempt.getResult() != null) {
                    msg = msg + " Result: " + attempt.getResult();
                }
                log.debug(msg);
            }
        }
    }
    
    /**
     * Returns the stack trace of the last exception obtained during the retry.
     * <p>
     * @return The string stack trace.
     */
    public String getStackTrace() {
        return stacktrace;
    }
}
