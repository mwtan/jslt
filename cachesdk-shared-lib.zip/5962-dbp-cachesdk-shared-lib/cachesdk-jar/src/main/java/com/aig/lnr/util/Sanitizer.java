package com.aig.lnr.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.owasp.encoder.Encode;

public final class Sanitizer {
    private static final Pattern CRLFPATTERN = Pattern.compile("\\R");
    private static final String CRLFREPLACEMENT = "__";
    
    // Prevent instantiation.
    private Sanitizer() {
        // No implementation
    }
 
    public static String sanitize(String inputString) {
        if (inputString == null) {
            return null;
        }
        else {
            Matcher matcher = CRLFPATTERN.matcher(inputString);
            return Encode.forHtml(matcher.replaceAll(CRLFREPLACEMENT));
        }
    } 
}
