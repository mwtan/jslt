package com.aig.exception;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class CommonExceptionTest {

    public CommonExceptionTest() {
    }

    @Before
    public void setUp() {
    }

    @Test
    public void test_empty_constructor() {
        CommonException e = new CommonException();
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("com.aig.exception.CommonException"));
    }

    @Test
    public void test_constructor_message() {
        CommonException e = new CommonException("myexception");
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("com.aig.exception.CommonException: myexception"));
    }

    @Test
    public void test_constructor_with_exception_parameter() {
        CommonException e = new CommonException(new Exception("Test exception"));
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("Test exception"));
    }

    @Test
    public void test_exception_chain1() {
        CommonException ex1 = new CommonException("ex1");
        CommonException ex2 = new CommonException("ex2", ex1);
        CommonException ex3 = new CommonException("ex3", ex2);
        // stack trace contains all 3 exceptions
        String s = ex3.getPrintStackTrace();
        assertTrue(s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from prior exception
        Exception enext = ex3.getNextCause();
        s = CommonException.getPrintStackTrace(enext);
        assertTrue(!s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from root cause
        Exception eroot = ex1.getRootCause();
        s = CommonException.getPrintStackTrace(eroot);
        assertTrue(!s.contains("ex3") && !s.contains("ex2") && s.contains("ex1"));
        // getNextCause of root exception
        Exception elast = ((CommonException) eroot).getNextCause();
        assertTrue(elast ==  null);
    }

    @Test
    public void test_exception_chain2() {
        try {
            method_a();
            fail("Failed");
        }
        catch (CommonException e) {
            // stack trace contains all 3 exceptions
            String s = e.getPrintStackTrace();
            assertTrue(s.contains("foo") && s.contains("bar") && s.contains("baz"));
            // stack trace from prior exception
            Exception enext = e.getNextCause();
            String snext = CommonException.getPrintStackTrace(enext);
            assertTrue(!snext.contains("foo") && snext.contains("bar") && snext.contains("baz"));
            // stack trace contains root exception
            Exception e1 = e.getRootCause();
            String s1 = CommonException.getPrintStackTrace(e1);
            assertTrue(!s1.contains("foo") && !s1.contains("bar") && s1.contains("baz"));
            // stack trace from getRootPrintStackTrace is the same as above
            String s2 = e.getRootPrintStackTrace();
            assertTrue(s1.equals(s2));
        }
    }
    public void method_a() throws CommonException {
        try {
            method_b();
            fail("Failed");
        }
        catch (Exception e) {
            throw new CommonException("foo", e);
        }
    }
    public static void method_b() throws CommonException {
        try {
            method_c();
        }
        catch (Exception e) {
            throw new CommonException("bar", e);
        }
    }
    public static void method_c() throws Exception {
        throw new Exception("baz");
    }
    
    @Test
    public void test_exception_message() {
        try {
            CommonException ce = new CommonException("Hello world!");
            String st = ce.getPrintStackTrace();
            assertTrue(st.contains("Hello world!"));
        }
        catch (Exception e) {
            fail("Failed");
        }
    }
}
