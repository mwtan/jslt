package com.aig.exception;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class CommonRuntimeExceptionTest {

	public CommonRuntimeExceptionTest() {
	}

    @Test
	public void test_empty_constructor() {
		CommonRuntimeException e = new CommonRuntimeException();
		String s = e.getPrintStackTrace();
		assertTrue(s.contains("test_empty_constructor(CommonRuntimeExceptionTest.java:15)"));
	}

    @Test
    public void test_constructor_with_exception_parameter() {
        CommonRuntimeException e = new CommonRuntimeException(new Exception("Test exception"));
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("Test exception"));
    }

    @Test
	public void test_exception_chain1() {
        CommonRuntimeException ex1 = new CommonRuntimeException("ex1");
        CommonRuntimeException ex2 = new CommonRuntimeException("ex2", ex1);
        CommonRuntimeException ex3 = new CommonRuntimeException("ex3", ex2);
        // stack trace contains all 3 exceptions
        String s = ex3.getPrintStackTrace();
        assertTrue(s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from prior exception
        Exception enext = ex3.getNextCause();
        s = CommonRuntimeException.getPrintStackTrace(enext);
        assertTrue(!s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from root cause
        Exception eroot = ex1.getRootCause();
        s = CommonRuntimeException.getPrintStackTrace(eroot);
        assertTrue(!s.contains("ex3") && !s.contains("ex2") && s.contains("ex1"));
        // getNextCause of root exception
        Exception elast = ((CommonRuntimeException) eroot).getNextCause();
        assertTrue(elast ==  null);
	}

    @Test
	public void test_exception_chain2() {
		try {
			method_a();
			fail("Failed");
		}
		catch (CommonRuntimeException e) {
			// stack trace contains all 3 exceptions
			String s = e.getPrintStackTrace();
			assertTrue(s.contains("foo") && s.contains("bar") && s.contains("baz"));
			// stack trace from prior exception
			Exception enext = e.getNextCause();
			String snext = CommonRuntimeException.getPrintStackTrace(enext);
			assertTrue(!snext.contains("foo") && snext.contains("bar") && snext.contains("baz"));
			// stack trace contains root exception
			Exception e1 = e.getRootCause();
			String s1 = CommonRuntimeException.getPrintStackTrace(e1);
			assertTrue(!s1.contains("foo") && !s1.contains("bar") && s1.contains("baz"));
			// stack trace from getRootPrintStackTrace is the same as above
			String s2 = e.getRootPrintStackTrace();
			assertTrue(s1.equals(s2));
		}
	}
	public void method_a() throws CommonRuntimeException {
		try {
			method_b();
			fail("Failed");
		}
		catch (Exception e) {
			throw new CommonRuntimeException("foo", e);
		}
	}
	public static void method_b() throws CommonRuntimeException {
		try {
			method_c();
		}
		catch (Exception e) {
			throw new CommonRuntimeException("bar", e);
		}
	}
	public static void method_c() throws InterruptedException {
		throw new InterruptedException("baz");
	}
}
