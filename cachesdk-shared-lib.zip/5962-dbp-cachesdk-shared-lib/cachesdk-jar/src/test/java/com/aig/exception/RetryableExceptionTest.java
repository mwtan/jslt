package com.aig.exception;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class RetryableExceptionTest {

    public RetryableExceptionTest() {
    }

    @Before
    public void setUp() {
    }

    @Test
    public void test_constructor_message() {
        RetryableException e = new RetryableException("myexception");
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("com.aig.exception.RetryableException: myexception"));
    }

    @Test
    public void test_constructor_with_exception_parameter() {
        RetryableException e = new RetryableException(new Exception("Test exception"));
        String s = e.getPrintStackTrace();
        assertTrue(s.contains("Test exception"));
    }

    @Test
    public void test_exception_chain1() {
        RetryableException ex1 = new RetryableException("ex1");
        RetryableException ex2 = new RetryableException("ex2", ex1);
        RetryableException ex3 = new RetryableException("ex3", ex2);
        // stack trace contains all 3 exceptions
        String s = ex3.getPrintStackTrace();
        assertTrue(s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from prior exception
        Exception enext = ex3.getNextCause();
        s = RetryableException.getPrintStackTrace(enext);
        assertTrue(!s.contains("ex3") && s.contains("ex2") && s.contains("ex1"));
        // stack trace from root cause
        Exception eroot = ex1.getRootCause();
        s = RetryableException.getPrintStackTrace(eroot);
        assertTrue(!s.contains("ex3") && !s.contains("ex2") && s.contains("ex1"));
        // getNextCause of root exception
        Exception elast = ((RetryableException) eroot).getNextCause();
        assertTrue(elast ==  null);
    }

    @Test
    public void test_exception_chain2() {
        try {
            method_a();
            fail("Failed");
        }
        catch (RetryableException e) {
            // stack trace contains all 3 exceptions
            String s = e.getPrintStackTrace();
            assertTrue(s.contains("foo") && s.contains("bar") && s.contains("baz"));
            // stack trace from prior exception
            Exception enext = e.getNextCause();
            String snext = RetryableException.getPrintStackTrace(enext);
            assertTrue(!snext.contains("foo") && snext.contains("bar") && snext.contains("baz"));
            // stack trace contains root exception
            Exception e1 = e.getRootCause();
            String s1 = RetryableException.getPrintStackTrace(e1);
            assertTrue(!s1.contains("foo") && !s1.contains("bar") && s1.contains("baz"));
            // stack trace from getRootPrintStackTrace is the same as above
            String s2 = e.getRootPrintStackTrace();
            assertTrue(s1.equals(s2));
        }
    }
    public void method_a() throws RetryableException {
        try {
            method_b();
            fail("Failed");
        }
        catch (Exception e) {
            throw new RetryableException("foo", e);
        }
    }
    public static void method_b() throws RetryableException {
        try {
            method_c();
        }
        catch (Exception e) {
            throw new RetryableException("bar", e);
        }
    }
    public static void method_c() throws Exception {
        throw new Exception("baz");
    }
    
    @Test
    public void test_exception_message() {
        try {
            RetryableException ce = new RetryableException("Hello world!");
            String st = ce.getPrintStackTrace();
            assertTrue(st.contains("Hello world!"));
        }
        catch (Exception e) {
            fail("Failed");
        }
    }
}
