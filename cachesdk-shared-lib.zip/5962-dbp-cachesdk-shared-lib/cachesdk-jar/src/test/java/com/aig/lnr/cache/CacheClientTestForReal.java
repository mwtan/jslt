package com.aig.lnr.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.time.StopWatch;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.redisson.api.annotation.REntity;
import org.redisson.api.annotation.RId;
import org.redisson.liveobject.resolver.UUIDGenerator;

import com.aig.lnr.secret.SecretsManager;
import com.aig.lnr.secret.VaultSecretProvider;
import com.aig.lnr.util.ConfigManager;

@Ignore ("Test using local Redis. Ignored for pipeline build.")
public class CacheClientTestForReal {

    @Before
    public void setUp() {
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_URL_PROP_KEY, "https://uat.cloud.api.aig.net/life/connext-secrets-api/v1/secrets/lnr/life/eventmanager");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_APIKEY_PROP_KEY, "AQ1Lh57p7mbVsQX8XmuwcFGk9GIGu10e");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_ROLEID_PROP_KEY, "7ee770d5-9ce4-b671-9116-415e65cf61a3");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_SECRETID_PROP_KEY, "99e364f0-fa97-d713-79da-b0e9ba12c616");
        System.setProperty(CacheClient.CONST_CACHE_URL_PROP, "rediss://clustercfg.elasticcachecluster-xe1-nprd-lnr-sso.bxytok.use1.cache.amazonaws.com:6379");
        System.setProperty(CacheClient.CONST_CACHE_CLUSTERMODE_PROP, "true");
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "");
        System.setProperty(CacheClient.CONST_CACHE_SECRETNAME_PROP, "credentials");
//        System.setProperty(CacheClient.CONST_CACHE_PPHRASE_PROP, "Aiglatesttestingcache2345<");
        ConfigManager.initialize();
        SecretsManager.reset();
        SecretsManager.getReference();
    }

    @Test
    public void test_getClusterInfo() {
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        assertNotNull(cacheclient.getClusterInfo());
    }
    
    @Test
    public void test_cache_using_single_server() {
        System.setProperty(CacheClient.CONST_CACHE_URL_PROP, "rediss://master.elasticcache-xe1-nprd-lnr.bxytok.use1.cache.amazonaws.com:6379");
        System.setProperty(CacheClient.CONST_CACHE_CLUSTERMODE_PROP, "false");
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "");
        System.setProperty(CacheClient.CONST_CACHE_SECRETNAME_PROP, "");
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s = "This is a test";
            cacheclient.storeObject("mykey", s);
            String sget = (String) cacheclient.fetchObject("mykey", String.class);
            assertEquals(s, sget);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_cache_with_appname() {
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "CacheSDK");
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s = "This is a test";
            cacheclient.storeObject("mykey", s);
            String sget = (String) cacheclient.fetchObject("mykey", String.class);
            assertEquals(s, sget);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_fetchObjectByKey() {
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "sso.user.service");
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String sget = (String) cacheclient.fetchObject("lnr-sso-outbound-dan_cachetest-dsuGuid-id", String.class);
            assertTrue(1 == 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_cache_with_ttl() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s = "This is a test";
            cacheclient.storeObject("myid", s, 10000);
            String sget = (String) cacheclient.fetchObject("myid", String.class);
            assertEquals(s, sget);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_cache_with_ttl_expire() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s = "This is a test";
            cacheclient.storeObject("myid", s, 100);
            try {
                Thread.sleep(200);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            String sget = (String) cacheclient.fetchObject("myid", String.class);
            assertTrue(sget == null);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_cache_replace_object() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is string 1";
            String s2 = "This is string 2";
            cacheclient.storeObject("myid", s1, 10000);
            String sgetandset = (String) cacheclient
                .replaceObject("myid", s2);
            assertEquals(s1, sgetandset);
            String sget = (String) cacheclient.fetchObject("myid", String.class);
            assertEquals(s2, sget);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_cache_list_object() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            List<String> l = new ArrayList<String>();
            l.add("String value one");
            l.add("String value two");
            cacheclient.storeObject("mylist", l, 1000000);

            List<String> lget = (List) cacheclient.fetchObject("mylist", ArrayList.class);
            Iterator<String> it = lget.iterator();
            int count = 0;
            while (it.hasNext()) {
                String s = (String) it.next();
                if (s.contains("String value ")) {
                    count++;
                }
            }
            assertTrue(count == 2);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @REntity
    public static class Policy implements Serializable {
        @RId(generator = UUIDGenerator.class)
        private String id;
        private String producttype;
        private double faceamount;

        public Policy() {
        }

        public void setId(String id) {
            this.id = id;
        }
        public String getId() {
            return id;
        }
        
        public void setProducttype(String producttype) {
            this.producttype = producttype;
        }
        public String getProducttype() {
            return producttype;
        }

        public void setFaceamount(double faceamount) {
            this.faceamount = faceamount;
        }
        public double getFaceamount() {
            return faceamount;
        }

        public String toString() {
            return new ToStringBuilder(this)
                    .append("id", getId())
                    .append("producttype", getProducttype())
                    .append("faceamount", getFaceamount())
                    .toString();
        }
    }
    
    @Test
    public void test_local_cache_map() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            Map map = cacheclient.fetchLocalCachedMap("mylocalmap");
            map.clear();
            map.put("key1", "value1");
            map.put("key2", "value2");

            Map map2 = cacheclient.fetchLocalCachedMap("mylocalmap");
            assertTrue(map2.containsKey("key1"));
            assertTrue(map2.containsKey("key2"));
            assertTrue(!map2.containsKey("key3"));
            
            map.put("key3", "value3");
            assertTrue(map2.containsKey("key3"));
            
            map2.put("key4", "value4");
            assertTrue(map.containsKey("key4"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_live_list() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            List list = cacheclient.fetchLiveList("mylist");
            list.clear();
            list.add("String value one");
            list.add("String value two");

            List list2 = cacheclient.fetchLiveList("mylist");
            assertTrue(list2.contains("String value one"));
            assertTrue(list2.contains("String value two"));
            assertTrue(!list2.contains("String value three"));
            
            list.add("String value three");
            assertTrue(list2.contains("String value three"));
            
            list2.add("String value four");
            assertTrue(list.contains("String value four"));
            assertTrue(cacheclient.deleteByPattern("mylist*") == 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_live_map() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            Map map = cacheclient.fetchLiveMap("mymap");
            map.clear();
            map.put("key1", "value1");
            map.put("key2", "value2");

            Map map2 = cacheclient.fetchLiveMap("mymap");
            assertTrue(map2.containsKey("key1"));
            assertTrue(map2.containsKey("key2"));
            assertTrue(!map2.containsKey("key3"));
            
            map.put("key3", "value3");
            assertTrue(map2.containsKey("key3"));

            map2.put("key4", "value4");
            assertTrue(map.containsKey("key4"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_live_queue() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            Queue queue = cacheclient.fetchLiveQueue("myqueue");
            queue.clear();
            queue.add("String value one");
            queue.add("String value two");

            Queue queue2 = cacheclient.fetchLiveQueue("myqueue");
            assertTrue(queue2.contains("String value one"));
            assertTrue(queue2.contains("String value two"));
            assertTrue(!queue2.contains("String value three"));
            
            queue.add("String value three");
            assertTrue(queue2.contains("String value three"));
            
            queue.remove();
            assertTrue(!queue2.contains("String value one"));

            queue2.remove();
            assertTrue(!queue.contains("String value two"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_live_set() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            Set set = cacheclient.fetchLiveSet("myset");
            set.clear();
            set.add("String value one");
            set.add("String value two");

            Set set2 = cacheclient.fetchLiveSet("myset");
            assertTrue(set2.contains("String value one"));
            assertTrue(set2.contains("String value two"));
            assertTrue(!set2.contains("String value three"));
            
            set.add("String value three");
            assertTrue(set2.contains("String value three"));

            set2.add("String value four");
            assertTrue(set.contains("String value four"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_live_sorted_set() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            SortedSet set = cacheclient.fetchLiveSortedSet("mysortedset");
            set.clear();
            set.add("String value one");
            set.add("String value two");

            SortedSet set2 = cacheclient.fetchLiveSortedSet("mysortedset");
            assertTrue(set2.contains("String value one"));
            assertTrue(set2.contains("String value two"));
            assertTrue(!set2.contains("String value three"));
            
            set.add("String value three");
            assertTrue(set2.contains("String value three"));

            set2.add("String value four");
            assertTrue(set.contains("String value four"));
            assertTrue(cacheclient.deleteByPattern("mysortedset*") == 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void test_getAllKeys() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            boolean key1found = false;
            boolean key2found = false;
            for (String s : cacheclient.getAllKeys()) {
                System.out.println(s);
                if (s.contains("mykey1")) {
                    key1found = true;
                }
                if (s.contains("mykey2")) {
                    key2found = true;
                }
            }
            assertTrue(key1found && key2found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_getKeysByPattern() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            boolean key1found = false;
            boolean key2found = false;
            for (String s : cacheclient.getKeysByPattern("mykey*")) {
                if (s.contains("mykey1")) {
                    key1found = true;
                }
                if (s.contains("mykey2")) {
                    key2found = true;
                }
            }
            assertTrue(key1found && key2found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_deleteByPattern() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            String s3 = "This is a test";
            cacheclient.storeObject("mykey3", s3);

            assertTrue(cacheclient.deleteByPattern("mykey1*") == 1);
            boolean key1found = false;
            boolean key2found = false;
            boolean key3found = false;
            for (String s : cacheclient.getAllKeys()) {
                System.out.println(s);
                if (s.contains("mykey1")) {
                    key1found = true;
                }
                if (s.contains("mykey2")) {
                    key2found = true;
                }
                if (s.contains("mykey3")) {
                    key3found = true;
                }
            }
            assertTrue(!key1found && key2found && key3found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_deleteByPattern_with_appname() {
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "CacheSDK");
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            String s3 = "This is a test";
            cacheclient.storeObject("mykey3", s3);
            showCache(cacheclient);

            assertTrue(cacheclient.deleteByPattern("mykey1*") == 1);
            boolean key1found = false;
            boolean key2found = false;
            boolean key3found = false;
            for (String s : cacheclient.getAllKeys()) {
                System.out.println(s);
                if (s.contains("mykey1")) {
                    key1found = true;
                }
                if (s.contains("mykey2")) {
                    key2found = true;
                }
                if (s.contains("mykey3")) {
                    key3found = true;
                }
            }
            assertTrue(!key1found && key2found && key3found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
            showCache(cacheclient);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_delete() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            String s3 = "This is a test";
            cacheclient.storeObject("mykey3", s3);

            assertTrue(cacheclient.delete(new String[]{"mykey1:java.lang.String"}) == 1);
            boolean key1found = false;
            boolean key2found = false;
            boolean key3found = false;
            for (String s : cacheclient.getAllKeys()) {
                System.out.println(s);
                if (s.contains("mykey1")) {
                    key1found = true;
                }
                if (s.contains("mykey2")) {
                    key2found = true;
                }
                if (s.contains("mykey3")) {
                    key3found = true;
                }
            }
            assertTrue(!key1found && key2found && key3found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_delete_with_appname() {
        System.setProperty(CacheClient.CONST_CACHE_APPNAME_PROP, "CacheSDK");
        ConfigManager.initialize();
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            String s1 = "This is a test";
            cacheclient.storeObject("mykey1", s1);
            String s2 = "This is a test";
            cacheclient.storeObject("mykey2", s2);
            String s3 = "This is a test";
            cacheclient.storeObject("mykey3", s3);
            showCache(cacheclient);
            
            assertTrue(cacheclient.delete(new String[] {"mykey1:java.lang.String"}) == 1);
            boolean key1found = false;
            boolean key2found = false;
            boolean key3found = false;
            for (String s : cacheclient.getAllKeys()) {
                System.out.println(s);
                if (s.contains("CacheSDK:mykey1")) {
                    key1found = true;
                }
                if (s.contains("CacheSDK:mykey2")) {
                    key2found = true;
                }
                if (s.contains("CacheSDK:mykey3")) {
                    key3found = true;
                }
            }
            assertTrue(!key1found && key2found && key3found);
            assertTrue(cacheclient.deleteByPattern("mykey*") == 2);
            showCache(cacheclient);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    private void showCache(CacheClient cacheclient) {
        Iterable<String> result = cacheclient.getAllKeys();
        if (result.iterator().hasNext()) {
            for (String s : result) {
                System.out.println("Found in cache: " + s);
            }
        }
        else {
            System.out.println("Cache is empty.");
        }
    }
    
    @Test
    public void test_delete_all() {
        CacheClient cacheclient = CacheClient.getInstance();
        try {
            cacheclient.deleteByPattern("*");
            Iterable<String> result = cacheclient.getAllKeys();
            assertTrue(!result.iterator().hasNext());
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Ignore
    @Test
    public void test_performance() {
        CacheClient cacheclient = CacheClient.getInstance();
        StopWatch sw = new StopWatch();
        sw.start();
        for (int i=0; i<100; i++) {
            String s = String.valueOf(Instant.now().toEpochMilli());
            cacheclient.storeObject("myid", s);
            cacheclient.fetchObject("myid", String.class);
        }
        sw.stop();
        System.out.println("New client. Time:" + sw.getTime());

        sw = new StopWatch();
        sw.start();
        for (int i=0; i<100; i++) {
            String s = String.valueOf(Instant.now().toEpochMilli());
            cacheclient.storeObject("myid", s);
            cacheclient.fetchObject("myid", String.class);
        }
        sw.stop();
        System.out.println("Reuse client. Time:" + sw.getTime());
        assertTrue(true);
    }
}
