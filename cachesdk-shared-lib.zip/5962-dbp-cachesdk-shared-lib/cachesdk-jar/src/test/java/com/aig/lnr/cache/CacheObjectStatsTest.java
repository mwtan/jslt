package com.aig.lnr.cache;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.Instant;

import org.junit.Test;

public class CacheObjectStatsTest {

    @Test
    public void test_getKey() {
        CacheObjectStats cos = new CacheObjectStats("mykey", Instant.now());
        assertEquals("mykey", cos.getKey());
    }
    
    @Test
    public void test_get_hits_misses() {
        CacheObjectStats cos = new CacheObjectStats("mykey", Instant.now());
        cos.incrementHitCount();
        cos.incrementHitCount();
        cos.incrementHitCount();
        cos.incrementMissCount();
        cos.incrementMissCount();
        assertEquals(3, cos.getHitCount());
        assertEquals(2, cos.getMissCount());
        try {
            Thread.sleep(10);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        assertTrue(cos.getElapsedMillis() > 0);
    }
    
}
