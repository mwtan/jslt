package com.aig.lnr.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import javax.ws.rs.core.Form;

import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.junit.Before;
import org.junit.Test;

public class ContextTest {

    public ContextTest() {
    }

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void test_Context_setType() {
        Context ctx = new Context();
        ctx.setType("XML");
        assertEquals(ctx.getType(), Context.TYPE_XML);
        ctx.setType("JSON");
        assertEquals(ctx.getType(), Context.TYPE_JSON);
        ctx.setType("JSON2XML");
        assertEquals(ctx.getType(), Context.TYPE_JSON);
        ctx.setType("UNKNOWN");
        assertEquals(ctx.getType(), "UNKNOWN");
    }

    @Test
    public void test_Context_setMethod() {
        Context ctx = new Context();
        ctx.setMethod(Context.METHOD_POST);
        assertEquals(ctx.getMethod(), Context.METHOD_POST);
    }

    @Test
    public void test_Context_toString() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.addQueryParameter("scope", "CEPRXYA");
        assertTrue(ctx.toString().contains("http://qa.abc.com"));
    }
    
    @Test
    public void test_Context_addFormParameter() {
        Context ctx = new Context();
        ctx.addFormParameter("mykey", "myvalue");
        Form form = ctx.getFormObject();
        Map formmap = form.asMap();
        assertTrue(formmap.containsKey("mykey"));
        ctx.addFormParameter("yourkey", "yourvalue");
        form = ctx.getFormObject();
        formmap = form.asMap();
        assertTrue(formmap.containsKey("yourkey"));
    }
    
    @Test
    public void test_addMultiPartFormParameter() {
        Context ctx = new Context();
        ctx.addMultiPartFormParameter("mykey", "myvalue");
        FormDataMultiPart form = ctx.getMultiPartFormObject();
        Map formmap = form.getFields();
        assertTrue(formmap.containsKey("mykey"));
        ctx.addMultiPartFormParameter("yourkey", "yourvalue");
        form = ctx.getMultiPartFormObject();
        formmap = form.getFields();
        assertTrue(formmap.containsKey("yourkey"));
    }
}
