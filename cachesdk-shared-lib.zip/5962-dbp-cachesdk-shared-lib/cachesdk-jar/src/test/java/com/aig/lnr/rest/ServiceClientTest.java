package com.aig.lnr.rest;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.Response;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;

import com.fasterxml.jackson.databind.JsonNode;

public class ServiceClientTest {
    @Mock
    Invocation.Builder ib;
    @Mock
    Response response;

    @InjectMocks @Spy
    ServiceClient client;
    
    Context ctx;
    Map<String, String> queryMap;
    Map<String, String> headerMap;
    
    public ServiceClientTest() {
    }

    @Before
    public void setUp() throws Exception {
        queryMap = new HashMap<String, String>();
        queryMap.put("scope", "CEPRXYA");    
        queryMap.put("search", "MIN");    
        queryMap.put("polnums", "0000000000008911681|||");
        headerMap = new HashMap<String, String>();
        headerMap.put("x-rapidapi-host", "apidojo-yahoo-finance-v1.p.rapidapi.com");    
        headerMap.put("x-rapidapi-key", "cf76a1bd6cmsh6817237c7cf0b4cp18f1c4jsn3e7be29db4fc");    
    }

    @Test
    public void test_get_request_xml() {
        ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.setAuthorization("ent-comm-manager", "xyzzy123");
        ctx.setType("XML");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        ctx.addQueryParameter("polnums", "0000000000008911681|||");
        ctx.addHeaderParameter("greeting", "HELLO");
//        ResponseBuilder responseBuilder = Response.ok();
//        Response response = responseBuilder.entity("<polNumber>00000000000008911681</polNumber>").build();
        
//        Response response = Mockito.mock(Response.class);
//        doReturn(200).when(response).getStatus();
//        doReturn("<polNumber>00000000000008911681</polNumber>").when(response).readEntity(Mockito.any(Class.class));
        
//        Mockito.when(response.getStatus()).thenReturn(200);
//        Mockito.when(response.readEntity(Mockito.any(Class.class))).thenReturn("<polNumber>00000000000008911681</polNumber>");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).when(response).getStatus();
            doReturn("<polNumber>00000000000008911681</polNumber>").
                when(response).readEntity(Mockito.any(Class.class));
            doReturn(response).when(ib).get();
            String out = client.getRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("<polNumber>00000000000008911681"));
        }
        catch (Exception e) {
            fail();
        }
    }

    @Test
    public void test_get_exception() {
        ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.setAuthorization("ent-comm-manager", "xyzzy123");
        ctx.setType("XML");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        ctx.addQueryParameter("polnums", "0000000000008911681|||");
        ctx.addHeaderParameter("greeting", "HELLO");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doThrow(new RuntimeException("ib.get() exception!")).
                when(ib).get();
            client.getRequest();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("ib.get() exception!"));
        }
    }

    @Test
    public void test_prepareRequest_exception() {
        ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.setAuthorization("ent-comm-manager", "xyzzy123");
        ctx.setType("XML");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        ctx.addQueryParameter("polnums", "0000000000008911681|||");
        ctx.addHeaderParameter("greeting", "HELLO");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doThrow(new RuntimeException("prepareRequest exception!")).
                when(client).prepareRequest(ArgumentMatchers.anyObject());
            client.init(ctx);
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("prepareRequest exception!"));
        }
    }

    @Test
    public void test_put_with_request_object() {
        Context ctx = new Context();
        ctx.setTarget("https://apis.dcextawssnd.abc.com/rest/ibmsilverpop");
        ctx.setPath("/rest/databases/5051410/consent/SMS-144540/18605340915");
        ctx.setAuthorization("Bearer " + "aPF1YZi1miyvSxsxwVB95vFmLsRuFMe0-tzWRbCGfpuoS1");
        ctx.setType("JSON");
        ctx.setRequestObject("{\"status\":\"OPTED-IN\"}");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).when(response).getStatus();
            doReturn("{\"error\":\"invalid_token\",\"error_description\":\"The access token\"}").
                when(response).readEntity(Mockito.any(Class.class));
            doReturn(response).when(ib).put(ArgumentMatchers.anyObject());
            String out = client.putRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("{\"error\":\"invalid_token\",\"error_description\":\"The access token"));
        }
        catch (Exception e) {
            fail();
        }
    }
    
    @Test
    public void test_put_with_query_param() {
        Context ctx = new Context();
        ctx.setTarget("https://apis.dcextawssnd.abc.com/rest/ibmsilverpop");
        ctx.setPath("/rest/databases/5051410/consent/SMS-144540/18605340915");
        ctx.setAuthorization("Bearer " + "aPF1YZi1miyvSxsxwVB95vFmLsRuFMe0-tzWRbCGfpuoS1");
        ctx.setType("JSON");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).when(response).getStatus();
            doReturn("{\"error\":\"invalid_token\",\"error_description\":\"The access token\"}").
                when(response).readEntity(Mockito.any(Class.class));
            doReturn(response).when(ib).put(ArgumentMatchers.anyObject());
            String out = client.putRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("{\"error\":\"invalid_token\",\"error_description\":\"The access token"));
        }
        catch (Exception e) {
            fail();
        }
    }

    @Test
    public void test_put_exception() {
        Context ctx = new Context();
        ctx.setTarget("https://apis.dcextawssnd.abc.com/rest/ibmsilverpop");
        ctx.setPath("/rest/databases/5051410/consent/SMS-144540/18605340915");
        ctx.setAuthorization("Bearer " + "aPF1YZi1miyvSxsxwVB95vFmLsRuFMe0-tzWRbCGfpuoS1");
        ctx.setType("JSON");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doThrow(new RuntimeException("ib.put() exception!")).
                when(ib).put(ArgumentMatchers.anyObject());
            client.putRequest();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("ib.put() exception!"));
        }
    }

    @Test
    public void test_post_with_request_object() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/billing/v1/agreements/22321246|||VNTG1/billing/payments/premiums/cc");
        ctx.setAuthorization("svc2usigcsspauth", "xyzzy123");
        ctx.addHeaderParameter("requestorid", "svc2usigcsspauth");
        ctx.setType("JSON");
        String req = "{ \"payment\": { \"paymentInitiatedEventID\":\"12345\", \"amount\": \"225.96\", \"accountNumber\": \"Ahj/7wSTFpNzwxOXZDjsESDdixYOGTFlKgza06lTYJclkjh/gClyWSOH+aQOxCnLuGTSTLdIDvagoE5MWk3PDE5dkOOwFFHg\", \"ccAuthorizationId\": \"5138819902926064204012\" } }";
        ctx.setRequestObject(req);
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(202).when(response).getStatus();
            doReturn("{\"fullTransactionId\":\"1234567\"}").
                when(response).readEntity(Mockito.any(Class.class));
            doReturn(response).when(ib).post(ArgumentMatchers.anyObject());
            String out = client.postRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("\"fullTransactionId\":\"1234567"));
            assertTrue(client.getResponseStatus() == 202);
        }
        catch (Exception e) {
            fail();
        }
    }
    
    @Test
    public void test_post_with_query_param() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/billing/v1/agreements/22321246|||VNTG1/billing/payments/premiums/cc");
        ctx.setAuthorization("svc2usigcsspauth", "xyzzy123");
        ctx.setHeaderParameters(headerMap);
        ctx.removeHeaderParameter("x-rapidapi-key");
        ctx.setType("JSON");
        ctx.setQueryParameters(queryMap);
        ctx.removeQueryParameter("scope");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).
                when(response).getStatus();
            doReturn("{\"fullTransactionId\":\"1234567\"}").
                when(response).readEntity(Mockito.any(Class.class));
            doReturn(response).
                when(ib).post(ArgumentMatchers.anyObject());
            String out = client.postRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("\"fullTransactionId\":\"1234567"));
            assertTrue(ctx.getHeaderParameters().get("x-rapidapi-key") == null);
            assertTrue(ctx.getQueryParameters().get("scope") == null);
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_post_with_form() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.setAuthorization("ent-comm-manager", "xyzzy123");
        ctx.setType("XML");
        ctx.addFormParameter("scope", "CEPRXYA");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).
                when(response).getStatus();
            doReturn("<polNumber>00000000000008911681</polNumber>").
                when(response).readEntity(Mockito.any(Class.class));
            when(ib.post(ArgumentMatchers.any(), ArgumentMatchers.eq(Response.class))).
                thenReturn(response);
            String out = client.postRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("<polNumber>00000000000008911681"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_post_with_multipart_form() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/agreements");
        ctx.setAuthorization("ent-comm-manager", "xyzzy123");
        ctx.setType("XML");
        ctx.addMultiPartFormParameter("mykey", "myval");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).
                when(response).getStatus();
            doReturn("<polNumber>00000000000008911681</polNumber>").
                when(response).readEntity(Mockito.any(Class.class));
            when(ib.post(ArgumentMatchers.any())).
                thenReturn(response);
            String out = client.postRequest();
            System.out.println("Response:" + out);
            assertTrue(out.contains("<polNumber>00000000000008911681"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_post_exception() {
        Context ctx = new Context();
        ctx.setTarget("http://qa.abc.com");
        ctx.setPath("/rest/billing/v1/agreements/22321246|||VNTG1/billing/payments/premiums/cc");
        ctx.setAuthorization("svc2usigcsspauth", "xyzzy123");
        ctx.addHeaderParameter("requestorid", "svc2usigcsspauth");
        ctx.setType("JSON");
        ctx.addQueryParameter("scope", "CEPRXYA");
        ctx.addQueryParameter("search", "MIN");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doThrow(new RuntimeException("ib.post() exception!")).
                when(ib).post(ArgumentMatchers.anyObject());
            client.postRequest();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("ib.post() exception!"));
        }
    }

    @Test
    public void test_delete() {
        Context ctx = new Context();
        ctx.setTarget("http://localhost:5000");
        ctx.setPath("/service/v1/environments/6da49106-9aae-11ea-9e06-fb72e1d8e897");
        ctx.setAuthorization("admin", "secret");
        ctx.setType("JSON");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doReturn(200).
                when(response).getStatus();
            doReturn("Success").
                when(response).readEntity(Mockito.any(Class.class));
            when(ib.delete()).
                thenReturn(response);
            String out = client.deleteRequest();
            assertTrue(out.contains("Success"));
        }
        catch (Exception e) {
            e.printStackTrace();
            fail();
        }
    }
    
    @Test
    public void test_delete_exception() {
        Context ctx = new Context();
        ctx.setTarget("http://localhost:5000");
        ctx.setPath("/service/v1/environments/6da49106-9aae-11ea-9e06-fb72e1d8e897");
        ctx.setAuthorization("admin", "secret");
        ctx.setType("JSON");
        try {
            client = new ServiceClient(ctx);
            initMocks(this);
            doThrow(new RuntimeException("ib.delete() exception!")).
                when(ib).delete();
            client.deleteRequest();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("ib.delete() exception!"));
        }
    }

    @Test
    public void test_get_and_setResponseStatus() {
        Context ctx = new Context();
        ctx.setTarget("http://localhost:5000");
        ctx.setPath("/service/v1/environments/6da49106-9aae-11ea-9e06-fb72e1d8e897");
        ctx.setAuthorization("admin", "secret");
        ctx.setType("JSON");
        try {
            client = new ServiceClient(ctx);
            client.setResponseStatus(201);
            assertTrue(client.getResponseStatus() == 201);
        }
        catch (Exception e) {
            fail();
        }
    }
    
    @Test
    public void test_toJsonNode() {
        try {
            String str = "{" +
                         "  \"menu\": {" +
                         "    \"id\": \"file\"," +
                         "    \"value\": \"File\"," +
                         "    \"popup\": {" +
                         "      \"menuitem\": [" +
                         "        {\"value\": \"New\", \"onclick\": \"CreateNewDoc()\"}," +
                         "        {\"value\": \"Open\", \"onclick\": \"OpenDoc()\"}," +
                         "        {\"value\": \"Close\", \"onclick\": \"CloseDoc()\"}" +
                         "      ]" +
                         "    }" +
                         "  }" +
                         "}";
            JsonNode node = ServiceClient.toJsonNode(str);
            String result = node.toString();
            assertTrue(result.contains("{\"menu\":{\"id\":\"file\",\"value\":\"File\""));
        }
        catch (Exception e) {
            fail(e.toString());
        }
    }
}
