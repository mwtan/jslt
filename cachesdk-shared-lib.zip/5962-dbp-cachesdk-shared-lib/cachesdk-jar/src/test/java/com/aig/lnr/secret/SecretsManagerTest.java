package com.aig.lnr.secret;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.aig.lnr.util.ConfigManager;

public class SecretsManagerTest {
    private static String CONST_RESPONSE = "{ \"secret\": { \"data\": { \"username\": \"secretuser\", \"password\": \"secretpass\" }}}";
    private static String CONST_RESPONSE2 = "{ \"secret\": { \"data\": { \"username\": \"secretuser2\", \"password\": \"secretpass2\" }}}";
    
    public SecretsManagerTest() {
    }

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void test_getSecrets() {
        try {
            System.setProperty(SecretsManager.CONST_SECRET_PROVIDER_PROP, "BOGUSPROVIDER");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager.getReference();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid secret provider type:"));
        }
    }

    @Test
    public void test_getSecrets_no_provider() {
        try {
            System.setProperty(SecretsManager.CONST_SECRET_PROVIDER_PROP, "");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_URL_PROP_KEY, "https://uat.cloud.api.aig.net/life/connext-secrets-api/v1/secrets/lnr/life/environment-on-demand");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_APIKEY_PROP_KEY, "AQ1Lh57p7mbVsQX8XmuwcFGk9GIGu10e");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_ROLEID_PROP_KEY, "8eba7ae6-2e19-5c09-be17-632490f4adb4");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_SECRETID_PROP_KEY, "9561a47f-5f5c-6244-4336-61e8fa9fa37d");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager.getReference();
        }
        catch (Exception e) {
            fail();
        }
    }

    @Test
    public void test_getSecrets_cached() {
        try {
            System.setProperty(SecretsManager.CONST_SECRET_PROVIDER_PROP, SecretsManager.CONST_SECRET_PROVIDER_VAULT);
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_URL_PROP_KEY, "https://uat.cloud.api.aig.net/life/connext-secrets-api/v1/secrets/lnr/life/environment-on-demand");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_APIKEY_PROP_KEY, "AQ1Lh57p7mbVsQX8XmuwcFGk9GIGu10e");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_ROLEID_PROP_KEY, "8eba7ae6-2e19-5c09-be17-632490f4adb4");
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_SECRETID_PROP_KEY, "9561a47f-5f5c-6244-4336-61e8fa9fa37d");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString(CONST_RESPONSE);
            Map m = secretsmanager.getSecrets("credentials");
            assertTrue(m.containsKey("username") && m.get("username").equals("secretuser"));
            assertTrue(m.containsKey("password") && m.get("password").equals("secretpass"));

            // Secrets is not re-retrieved but obtained from cache
            VaultSecretProvider.setTestmodeObjectString(CONST_RESPONSE2);
            m = secretsmanager.getSecrets("credentials");
            assertTrue(m.containsKey("username") && m.get("username").equals("secretuser"));
            assertTrue(m.containsKey("password") && m.get("password").equals("secretpass"));
        }
        catch (Exception e) {
            fail(e.toString());
        }
    }
}
