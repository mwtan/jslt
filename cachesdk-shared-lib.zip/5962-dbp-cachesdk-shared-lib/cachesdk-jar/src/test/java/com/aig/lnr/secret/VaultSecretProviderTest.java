package com.aig.lnr.secret;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.aig.lnr.util.AbstractServiceRetry;
import com.aig.lnr.util.ConfigManager;

/**
 * Test class for HashiVaultSecret.
 * <p>
 * @author Will Tan 
 */
public class VaultSecretProviderTest {
    private static String CONST_RESPONSE = "{ \"secret\": { \"data\": { \"username\": \"secretuser\", \"password\": \"secretpass\" }}}";
    
    public VaultSecretProviderTest() {
    }

    @Before
    public void setUp() throws Exception {
        System.setProperty(SecretsManager.CONST_SECRET_PROVIDER_PROP, "");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_URL_PROP_KEY, "https://uat.cloud.api.aig.net/life/connext-secrets-api/v1/secrets/lnr/life/environment-on-demand");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_APIKEY_PROP_KEY, "AQ1Lh57p7mbVsQX8XmuwcFGk9GIGu10e");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_ROLEID_PROP_KEY, "8eba7ae6-2e19-5c09-be17-632490f4adb4");
        System.setProperty(VaultSecretProvider.CONST_DEFAULT_SECRETID_PROP_KEY, "9561a47f-5f5c-6244-4336-61e8fa9fa37d");
    }

    @Ignore ("Call the real Vault API")
    @Test
    public void test_getSecrets_using_api_call() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(false);
            Map m = secretsmanager.getSecrets("credentials");
            assertTrue(m.get("system.db.username").equals("service_envmgr_dev"));
            assertTrue(m.get("system.db.password").equals("S3rv1ce_3m_envmgr_dev"));
        }
        catch (Exception e) {
            fail(e.toString());
        }
    }

//    @Test
//    public void test_getSecrets_missing_properties() {
//        try {
//            ConfigManager.initialize();
//            SecretsManager.reset();
//            SecretsManager secretsmanager = SecretsManager.getReference();
//            fail();
//        }
//        catch (Exception e) {
//            assertTrue(e.getMessage().contains("[SecretsManager] Invalid secret provider type"));
//        }
//    }

    @Test
    public void test_getSecrets() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString(CONST_RESPONSE);
            Map m = secretsmanager.getSecrets("credentials");
            assertTrue(m.containsKey("username") && m.get("username").equals("secretuser"));
            assertTrue(m.containsKey("password") && m.get("password").equals("secretpass"));
        }
        catch (Exception e) {
            fail(e.toString());
        }
    }

    @Test
    public void test_getSecrets_missing_url_value() {
        try {
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_URL_PROP_KEY, "");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Missing value for property vault.base.url"));
        }
    }

    @Test
    public void test_getSecrets_missing_apikey_value() {
        try {
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_APIKEY_PROP_KEY, "");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Missing value for property vault.api.key"));
        }
    }

    @Test
    public void test_getSecrets_missing_roleid_value() {
        try {
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_ROLEID_PROP_KEY, "");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Missing value for property vault.role.id"));
        }
    }

    @Test
    public void test_getSecrets_missing_secretid_value() {
        try {
            System.setProperty(VaultSecretProvider.CONST_DEFAULT_SECRETID_PROP_KEY, "");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Missing value for property vault.secret.id"));
        }
    }

    @Test
    public void test_getSecrets_throw_runtimeexception() {
        try {
            System.setProperty(AbstractServiceRetry.SYS_RETRYTIMES, "1");
            System.setProperty(AbstractServiceRetry.SYS_RETRYWAITMS, "100");
            System.setProperty(AbstractServiceRetry.SYS_RETRYMAXWAITMS, "500");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeThrowException(true);
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Test RuntimeException."));
        }
    }

    @Test
    public void test_getSecrets_throw_executionsexception() {
        try {
            System.setProperty(AbstractServiceRetry.SYS_RETRYTIMES, "1");
            System.setProperty(AbstractServiceRetry.SYS_RETRYWAITMS, "100");
            System.setProperty(AbstractServiceRetry.SYS_RETRYMAXWAITMS, "500");
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeThrowExecutionException(true);
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Test ExecutionException."));
        }
    }

    @Test
    public void test_getSecrets_empty_secrets() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString("");
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("null secret result."));
        }
    }
    
    @Test
    public void test_getSecrets_null_secrets() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString(null);
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("null secret result."));
        }
    }

    @Test
    public void test_getSecrets_bad_json_data() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString("{ \"secret\": { \"data\": { \"username\": \"secretuser\", \"password\": \"secretpass\", }}}");
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("[VaultSecretProvider] Error parsing secret response."));
        }
    }

    @Test
    public void test_getSecrets_bad_request() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString("{ \"secret\": { \"data\": { \"username\": \"Bad Request\", \"password\": \"400\" }}}");
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("[VaultSecretProvider] Bad response from Vault."));
        }
    }

    @Test
    public void test_getSecrets_empty_json_data() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString("");
            secretsmanager.getSecrets("credentials");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("[VaultSecretProvider] Secretname:") &&
                       e.getMessage().contains("null secret result."));
        }
    }

    @Test
    public void test_getSecrets_no_retry_configs() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager secretsmanager = SecretsManager.getReference();
            secretsmanager = SecretsManager.getReference();
            VaultSecretProvider.setTestmode(true);
            VaultSecretProvider.setTestmodeObjectString(CONST_RESPONSE);
            SecretsManager.getProvider().setRetry(1, 100, 500);
            Map m = secretsmanager.getSecrets("credentials");
            assertTrue(m.containsKey("username") && m.get("username").equals("secretuser"));
            assertTrue(m.containsKey("password") && m.get("password").equals("secretpass"));
        }
        catch (Exception e) {
            fail(e.toString());
        }
    }
    
    @Test
    public void test_jsonToMap() {
        try {
            ConfigManager.initialize();
            SecretsManager.reset();
            SecretsManager.getReference();
            AbstractSecretProvider provider = SecretsManager.getProvider();
            provider.jsonToMap("");
            fail();
        }
        catch (Exception e) {
            assertTrue(e.getMessage().contains("Error reading JSON:"));
        }
    }
    
    @Test
    public void test_get_retry_attributes() {
        System.setProperty(AbstractServiceRetry.SYS_RETRYTIMES, "");
        System.setProperty(AbstractServiceRetry.SYS_RETRYWAITMS, "");
        System.setProperty(AbstractServiceRetry.SYS_RETRYMAXWAITMS, "");
        ConfigManager.initialize();
        SecretsManager.reset();
        SecretsManager.getReference();
        AbstractSecretProvider provider = SecretsManager.getProvider();
        assertEquals(AbstractServiceRetry.CONST_DEFAULT_RETRYTIMES, provider.getRetrytimes());
        assertEquals(AbstractServiceRetry.CONST_DEFAULT_RETRYWAITMS, provider.getRetrywaitms());
        assertEquals(AbstractServiceRetry.CONST_DEFAULT_RETRYMAXWAITMS, provider.getRetrymaxwaitms());
    }
}
