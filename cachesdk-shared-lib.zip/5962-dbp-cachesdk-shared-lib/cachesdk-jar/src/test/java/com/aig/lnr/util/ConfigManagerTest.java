package com.aig.lnr.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class ConfigManagerTest {
    private static final String CONST_TESTPROP = "src/test/resources/test.properties";

    @Before
    public void setUp() {
        ConfigManager.setPropfile(CONST_TESTPROP);
        ConfigManager.initialize();
    }

    @Test
    public void test_getProperty() {
        assertTrue(ConfigManager.getProperty("cache.url").contains("rediss://"));
    }

    @Test
    public void test_getProperty_do_not_use_default_value() {
        assertTrue(ConfigManager.getProperty("cache.url", "default").contains("rediss://"));
    }

    @Test
    public void test_getProperty_use_default_value() {
        assertTrue(ConfigManager.getProperty("bogus", "default").contains("default"));
    }

    @Test
    public void test_getBooleanProperty() {
        assertTrue(ConfigManager.getBooleanProperty("cache.clustermode", true));
    }

    @Test
    public void test_getBooleanProperty_default_value() {
        assertFalse(ConfigManager.getBooleanProperty("cache.bogus", false));
    }
}
