package com.aig.lnr.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class SanitizerTest {
    
    @Test
    public void test_sanitize_null_input() {
        assertNull(Sanitizer.sanitize(null));
    }

    @Test
    public void test_sanitize() {
        assertEquals("hello __there.__", Sanitizer.sanitize("hello \rthere.\r\n"));
    }
}
